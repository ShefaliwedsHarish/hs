<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>

<style> 
body{
    margin-top:100px;
    background:#f5f5f5;

}

.container {
    width: 50%;
    background-color: blue;
    border-radius:5%;
    height: 550px;
}

.user_name {
    height: 50px;
    background-color:#63F416;
}

.col-6 {
    margin-top: 30px;
}

label {
    color:white;
    
      }

.heading
{
   background-color: white;

}

h4
{
  text-align: center;

}
/**
 * Panels
 */
/*** General styles ***/

</style>



<div class="container"> 



<div class="row">
<div class="col user_name"> 
    <h4>  {{$itr2->Pan_card}} </h4>
</div> 
</div> 
<!-- for name  -->
<div class="row"> 
  <div class="col-6"> 
  <label for="email">Name </label>
</div>
<div class="col-6"> 
      <input type="text" class="form-control" id="email" placeholder="Name"  value="{{$itr2->Name}}"name="email" readonly="">
</div>
</div> 

<!-- For email   -->
<div class="row"> 
  <div class="col-6"> 
  <label for="email">Email </label>
</div>
<div class="col-6"> 
      <input type="text" class="form-control" id="email" placeholder="Name" name="email" value="{{$itr2->Email}}" readonly="">
</div>
</div> 
 
<!-- For Phone_number   -->
<div class="row"> 
  <div class="col-6"> 
  <label for="email">Phone number  </label>
</div>
<div class="col-6"> 
      <input type="text" class="form-control" id="email" placeholder="Name" name="email" value="{{$itr2->Phone_number}}" readonly="">
</div>
</div> 
 


<!-- For Phone_number   -->
<div class="row"> 
  <div class="col-6"> 
  <label for="email">Address </label>
</div>
<div class="col-6"> 
      <input type="text" class="form-control" id="email" placeholder="Name" name="email" value="{{$itr2->Address}}" readonly="">
</div>
</div> 

<!-- For Phone_number   -->
<div class="row"> 
  <div class="col-6"> 
  <label for="email">Password   </label>
</div>
<div class="col-6"> 
      <input type="text" class="form-control" id="email" placeholder="Name" name="email" value="{{$itr2->Password}}" readonly="">
</div>
</div> 



<!-- For Phone_number   -->
<div class="row"> 
  <div class="col-6"> 
  <label for="email">Option  </label>
</div>
<div class="col-6"> 
      <select class="form-control"> 

 
        <option> Pendding</option>
    
    
        <option> Approve  </option>
     
      </select>
</div>
</div> 

<button >  Update </button>

</div>