


<style> 
.divider:after,
.divider:before {
content: "";
flex: 1;
height: 1px;
background: #eee;
}
</style> 

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>



<nav class="navbar navbar-expand-lg  navbar-dark bg-dark  px-lg-3 pt-lg- shadow-sm fixed-top"> 
  <div class="container-fluid">
    <a class="navbar-brand" href="#">HSGroup</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="/" >Home</a>
        </li>


        
  <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="/about" >About Us </a>
        </li>


        
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Service  
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="/online">Online</a></li>
            <li><a class="dropdown-item" href="/ch">Material</a></li>
            <li><a class="dropdown-item" href="#">Loan</a></li>
            <li><a class="dropdown-item" href="#">KST Requirement</a></li>
            <li><a class="dropdown-item" href="/dairy">Dairy</a></li>
            <li><a class="dropdown-item" href="/photo">Printing</a></li>
            
          </ul>
        </li>
      
      
  <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="/contact" >Contact us </a>
        </li>




        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="/photo" >Photo </a>
        </li>
 
      </ul>
     </div>
  </div>
</nav>

<!-- =====all details === -->
<section class="vh-100">
  <div class="container py-5 h-100">
    <div class="row d-flex align-items-center justify-content-center h-100">
      <div class="col-md-8 col-lg-7 col-xl-6">
        <img src="https://mdbcdn.b-cdn.net/img/Photos/new-templates/bootstrap-login-form/draw2.svg"
          class="img-fluid" alt="Phone image">
      </div>
      <div class="col-md-7 col-lg-5 col-xl-5 offset-xl-1">
       <form action="{{route('login')}}" method="POST">
        @csrf
          <!-- Email input -->
          <div class="form-outline mb-4">
            <input type="text" id="form1Example13" class="form-control form-control-lg" name="user" />
            <label class="form-label" for="form1Example13">User Id</label>
          </div>

          <!-- Password input -->
          <div class="form-outline mb-4">
            <input type="password" id="form1Example23" class="form-control form-control-lg" name="password"/>
            <label class="form-label" for="form1Example23">Password</label>
          </div>

          <div class="d-flex justify-content-around align-items-center mb-4">
            <!-- Checkbox -->
           
           
          </div>

          <!-- Submit button -->
          <button type="submit" class="btn btn-primary btn-lg btn-block">Login </button>

          <div class="divider d-flex align-items-center my-4">
            <p class="text-center fw-bold mx-3 mb-0 text-muted">OR</p>
          </div>

          <a class="btn btn-primary btn-lg btn-block" style="background-color: #3b5998" href="#!"
            role="button">
            <i class="fab fa-facebook-f me-2"></i>Register 
          </a>
          <a class="btn btn-primary btn-lg btn-block" style="background-color: #55acee" href="#!"
            role="button">
            <i class="fab fa-twitter me-2"></i>Forgot Password</a>

        </form>
      </div>
    </div>
  </div>
</section>