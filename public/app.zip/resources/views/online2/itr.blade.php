@include('folder/header'); 
@include('folder/link');

<script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
<script> 



</script>
<br> <br> 
<div class="ch" style="position:fixed;width:100%;height:70px;background-color:white;margin-top:8px"> 
<h1 style="text-align:center">   Online  Serive  <hr style="width:20%;margin-left:40%">  </h1> 
</div> 
<br> 
<div class="per" style="width:50%;margin-left:42%">
<br> <br> <br> 
<p>  <a href="/epfoform"> <button type="button" class="btn btn-secondary" id="epfo" value="EPFO">EPFO </button> </a> &nbsp; &nbsp; 
  <a href="/itr_form"> <button type="button" class="btn btn-info" id="itr" value="ITR">ITR</button> </a>  &nbsp; &nbsp;  
<a href="/online2"><button type="button" class="btn btn-warning" id="online" value="Online Form">Online Form </button></a> </p> 
</div> 

<div class="part2" style="background-color:black"> 
 <h1 style="color:white;text-align:center" id="act"> ITR   </h1> 
</div>  
<div class="container" style="background-color:pink; border:7px solid green">

   @if($message = Session::get('success'))
<div class="alert alert-success alert-block">

<strong>  {{  $message }}</strong>

 </div>
@endif


 <form action="/itr2" method="POST" enctype="multipart/form-data">
    @csrf
      <div class="modal-body">
      <div  class="row"> 
    <div class="col-6"> 

<div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Name</label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="name" value="{{old('name')}}" >
   

   @if($errors->has('name'))
   <span class="alert-danger" role="alert"> {{ $errors->first('name')}}</span>
   @endif
  </div>

    </div> 
    <div class="col-6"> 

<div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Email </label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"  name="email" value="{{old('name')}}">
    
   @if($errors->has('email'))
   <span class="alert-danger" role="alert"> {{ $errors->first('email')}}</span>
   @endif

  </div>
             </div> 
    </div> 
      
  


        <div  class="row"> 
    <div class="col-6"> 

<div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Phone Number </label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp"name="phone" value="{{old('name')}}">
   
   @if($errors->has('phone'))
   <span class="alert-danger" role="alert"> {{ $errors->first('phone')}}</span>
   @endif
  </div>

    </div> 
    <div class="col-6"> 

<div class="mb-3">
    <label for="exampleInputEmail1" class="form-label"> Addhar card    </label>
    <input type="file" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="addhar" value="{{old('name')}}">
   
   @if($errors->has('addhar'))
   <span class="alert-danger" role="alert"> {{ $errors->first('addhar')}}</span>
   @endif
  </div>
             </div> 
    </div> 

      <div  class="row"> 
    <div class="col ">
<label for="exampleInputEmail1" class="form-label">Address   </label>
<div class="form-floating">
  <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea"  name="address" value="{{old('name')}}"></textarea>
  
   @if($errors->has('address'))
   <span class="alert-danger" role="alert"> {{ $errors->first('address')}}</span>
   @endif


  </div>


             </div> 
    </div>






        <div  class="row"> 
    <div class="col-6"> 

<div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Pan Number   </label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="pancard" value="{{old('name')}}">
   
   @if($errors->has('pancard'))
   <span class="alert-danger" role="alert"> {{ $errors->first('pancard')}}</span>
   @endif

  </div>

    </div> 
    <div class="col-6"> 

<div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Password   </label>
    <input type="password" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="password" value="{{old('name')}}">
   

   @if($errors->has('password'))
   <span class="alert-danger" role="alert"> {{ $errors->first('password')}}</span>
   @endif

  </div>
             </div> 
    </div> 
             <input type="submit"  class="btn btn-success" id="submit" style="margin-left:45%"> 

</form> 
        










