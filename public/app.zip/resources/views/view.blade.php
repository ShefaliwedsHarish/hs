@include('folder/header');
@include('folder/link'); 
<script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
<script> 
$(document).ready(function ()
{
  $("#next").hide(); 
  $("#summary").hide(); 
  $("#submit").hide(); 

  $("#bk").on("click",function ()
  {
    var c=$(this).val(); 
    show (c); 
    }); 

  $("#bka").on("click",function ()
  {
    var c=$(this).val(); 
    show (c); 
  }); 

  $("#next").on("click",function ()
  {
    var na=$("#gd").text();
    if(na=="Groom")
    {
        $("#gd").text("Bride");   
        $("#nam").text("Bride");        
         }
         else
         {
           $("#gd").text("Groom"); 
           $("#nam").text("Groom"); 
         }   
    $(".Groom").hide(); 
    $(".Bride").show(); 
    $("#next").hide()
    $("#summary").show(); 
    $("#submit").show(); 
   });
});

function show(a)
{
$("#next").show(); 
$(".title").show(); 
$(".Groom").show(); 
$(".top").hide(); 
$(".sele").hide(); 
$("#name").text(a);
$("#gd").text(a);
}
</script> 
<br> <br> 
<div class="ch" style="position:fixed;width:100%;height:70px;background-color:white;margin-top:8px"> 
<h1 style="text-align:center"> Views Product <hr style="width:20%;margin-left:40%">  </h1> 
</div>  <br> <br> <br> 

<div class="part2" style="background-color:black;margin-top:20px"> 
 <h1 style="color:white;text-align:center"> T-Shirt</h1> 
</div> 
 
 <div class="container"> 
 <div class="row"> 
  <div class="col-7"> 
 <img src="managment/mylife2.png" style="width: 80%;">
 </div> 


  <div class="col-5"> 
  <h5 style="text-align:center"> T-Shirt </h5> 
  <h6> Price :             500 ₹ per pieace  </h6> 
  <h6>  Discount :         10% </h6> 
  <h6> Information :        Lorem ipsum dolor sit amet consectetur, adipisicing elit. Enim magni, eius placeat nam excepturi corrupti 
pariatur autem delectus doloribus explicabo, exercitationem distinctio tempore officia voluptatem aut est quod accusamus. Dolorem? </h6> 
<br> <br> 
<button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#Buy" style="margin-left:1%">
    Buy 
</button>
 </div>
 
<div class="modal fade" id="buy" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header" style="margin-top:-5%" >   
      <div class="top" style="margin-top:50px;"> Which Side you Booking  </div> 
   <div class="title" style="display:none;margin-top:4%;margin-left:40%;"> 
   <h1 class="modal-title fs-5" id="buy" style="margin-left:40%">Buy </h1>
     <h5 style="margin-top:8%;margin-left: -9%"> <span id="gd"> Groom  </span> Details </h5>
      </div> 
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
      
      <form action="/order" method="POST">
        @csrf
          <div class="modal-body">
       <div class="sele"> 
      <div class="form-check">
  <input class="form-check-input" type="radio" name="select" id="bk" Value="Groom">
  <label class="form-check-label" for="flexRadioDefault1">
   <h5>  Groom </h5> 
  </label>
</div>


<div class="form-check" >
  <input class="form-check-input" type="radio" name="select" id="bka" Value="Bride">
  <label class="form-check-label" for="flexRadioDefault1">
   <h5>  Bride </h5>  
  </label>
</div>

</div> 
      <div class="Groom" style="display:none">   
     <h5 style="margin-left:40%"> Date of  Marrage  </h5> 
          <div  class="row"> 
    <div class="col-6"> 
<div class="mb-3">
    <label for="exampleInputEmail1" class="form-label"> Start  of Date </label>
    <input type="Date" class="form-control"  name="startdata" aria-describedby="emailHelp" id="start">
     </div>
    </div> 

    <div class="col-6"> 
     <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label"> End of Date  </label>
    <input type="Date" class="form-control" name ="enddate" aria-describedby="emailHelp" id="end">
     </div>
     </div> 
     </div> 
      
  


    <div  class="row"> 
    <div class="col-6"> 
    <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label"> <span id="name"> Groom  </span>  Name </label>
    <input type="text" class="form-control" id="groom" aria-describedby="emailHelp">
    </div>
    </div> 

    <div class="col-6"> 
    <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Place of Marrage   </label>
    <input type="text" class="form-control" name="place" id="pm" aria-describedby="emailHelp">
    </div>
   </div> 
   </div> 

   <div  class="row"> 
   <div class="col ">
   <label for="exampleInputEmail1" class="form-label">Address   </label>
   <div class="form-floating">
   <textarea class="form-control" name="address" id="add"></textarea>
  <label for="floatingTextarea">Address </label>
  </div>
  </div> 
  </div>






  <div  class="row"> 
  <div class="col-6"> 
  <div class="mb-3">
  <label for="exampleInputEmail1" class="form-label">Father Name </label>
  <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>
  </div> 

  <div class="col-6"> 
  <div class="mb-3">
  <label for="exampleInputEmail1" class="form-label"> Mother  Name </label>
  <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
  </div>
  </div> 
  </div> 
  


  <div  class="row"> 
  <div class="col ">
<label for="exampleInputEmail1" class="form-label">Extra word     </label>
<div class="form-floating">
<textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea"></textarea>
<label for="floatingTextarea">Word  </label>
</div>
</div> 
</div>
</div> 

{{-- bride  --}}

      <div class="bride" style="display:none">
      <div  class="row"> 
      <div class="col-6"> 
      <div class="mb-3">
      <label for="exampleInputEmail1" class="form-label"> <span id="nam"> Bride </span>  Name </label>
      <input type="text" class="form-control" id="groom" aria-describedby="emailHelp">
      </div>
      </div> 
  
    <div class="col-6"> 
    <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Phone Number </label>
    <input type="text" class="form-control" id="pm" aria-describedby="emailHelp">
    </div>
    </div> 
    </div> 


  

    <div  class="row"> 
    <div class="col-6"> 
     <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Father  Name </label>
    <input type="text" class="form-control" id="groom" aria-describedby="emailHelp">
    </div>
    </div> 

    <div class="col-6"> 
    <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Mother Name    </label>
    <input type="text" class="form-control" id="pm" aria-describedby="emailHelp">
     </div>
     </div> 
     </div> 




 
     <div  class="row"> 
     <div class="col ">
    <label for="exampleInputEmail1" class="form-label">Address   </label>
    <div class="form-floating">
    <textarea class="form-control" placeholder="Leave a comment here" id="add"></textarea>
    <label for="floatingTextarea">Address </label>
    </div>
    </div> 
    </div>
    </div>
    </div> 
 
 
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" id="next">Next</button>
        <button type="button" class="btn btn-info" id="summary">Summary</button>
        <button type="button" class="btn btn-success" id="submit">Submit</button>
        </form> 
      </div>
    </div>
  </div>
</div>
 