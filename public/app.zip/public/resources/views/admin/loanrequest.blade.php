@include('admin/header')

@php 
$folder='EPFO';
$url=url('/'); 
@endphp 
<style> 
	.right {
    float: right;
}
	</style>
<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

<!-- Toastr CSS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<!-- Toastr JS (after jQuery) -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
</head>


<style> 
  /* .card-body {
      display: none;
  } */
  
  strong {
      margin-left: 20px;
      margin-top: 20px;
  }
  
  .spinner-border.ml-auto {
      text-align: right;
      margin-left: 77%;
      margin-top: 20px;
  }
 .reasonlist {
    display: none;
}
  </style> 

<script> 



$(document).ready(function ()
{
  $('[data-bs-dismiss="modal"]').click(function (){
   $(".reasonlist").hide(); 
  });

  
  $(document).on("click",".view",function ()
  {

    $(".card-body").hide(); 
    var id= $(this).data("id"); 
    var action="loanview"; 
   $.ajax({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
            url:"/admin/"+id+"/"+action,
             type:"POST",
             success:function (d)
             { 
              $(".card-body").show(); 
              $(".spinner-border.ml-auto").hide(); 
              $("strong").hide(); 

              console.log(d);
              // alert(d); 
              var data=JSON.parse(d); 
              jQuery("#id").val(data.id); 
              jQuery("#betchid").text(data.betch_id); 
              jQuery("#name").text(data.name);
              jQuery("#payment").text(data.payment);
              jQuery("#paymentreturn").text(data.paymentreturn);
              jQuery("#profit").text(data.profit);
              jQuery("#requestdate").text(data.requestdate);
              jQuery("#returndate").text(data.returndate);
              jQuery("#phone_number").text(data.phone_number);
              jQuery("#method").text(data.method);
             if(data.status==0){
              jQuery("#status").text("Under Process");
               } else if(data.status==1){
              jQuery("#status").text("Approved ");
               }else if(data.status==2){
              jQuery("#status").text("UnApproved");
              jQuery(".reasonlist").show(); 
              jQuery("#reasoncheck").text(data.reason);              
               }    
              
               //jquery("#rid").val(data.id); 
             }
            
    });  

  }); 



  function reload() {
  location.reload();
}


  $(document).on("click",".delete",function ()
  {
    var id= $(this).data("did"); 
    var action="delete"; 
  $.ajax({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
            url:"/admin/"+id+"/"+action,
             type:"POST",
             success:function (d)
             { 
               var data=JSON.parse(d); 
               if(data.status==true){
                   toastr.success(data.message, { timeOut: 9500 });
                   const myTimeout = setTimeout(reload, 1000);
                 }
                          
             }
            
    });  
  });
  
  // approve and  unapprove

  $("#approve").on("click",function (){

  var id=$("#id").val(); 
  var action="approve"; 
  $.ajax({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
            url:"/admin/"+id+"/"+action,
             type:"POST",
             success:function (d)
             { 
               var data=JSON.parse(d); 
               if(data.status==true){
                   toastr.success(data.message, { timeOut: 9500 });
                   const myTimeout = setTimeout(reload, 1000);
                 }
                          
             }
            
    });  
  }); 


  $("#unapprove").on("click",function (){
   
    
    var id=$("#id").val();
      $("#rid").val(id); 
      $("#reason").focus(); 
  }); 

  $(".unapprovesub").on("click",function (){
   
    var id=$("#rid").val(); 
    var reason=$("#reason").val(); 
    if(reason!=''){
      var action="unapprove"; 
  $.ajax({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
            url:"/admin/"+id+"/"+action,
             type:"POST",
             data:{'reason':reason},
             success:function (d)
             { 
               var data=JSON.parse(d); 
               if(data.status==true){
                   toastr.success(data.message, { timeOut: 9500 });
                   const myTimeout = setTimeout(reload, 1000);
                 }
                          
             }
            
    });  
    }


  }); 

// var id=$("#id").val(); 
// var action="approve"; 
// $.ajax({
//   headers: {
//       'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
//   },
//           url:"/admin/"+id+"/"+action,
//            type:"POST",
//            success:function (d)
//            { 
//              var data=JSON.parse(d); 
//              if(data.status==true){
//                  toastr.success(data.message, { timeOut: 9500 });
//                  const myTimeout = setTimeout(reload, 1000);
//                }
                        
//            }
          
//   });  

  


  




}); 


</script> 

        
<meta name="csrf-token" content="{{ csrf_token() }}" />



            <!-- Table Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4" >
                    <div class="col-sm-12 col-xl-6" style="width:100%">
                        <div class="bg-light rounded h-100 p-4" style="overflow:scroll">
           <!-- epfo start  -->
                            <h6 class="mb-4">Loan </h6>
                            <table class="table">
                                <thead>
                                    <tr>
                                        {{-- <th scope="col">Id</th> --}}
                                        <th scope="col">Name</th>
                                        <th scope="col">Payment</th>
                                     <!--    <th scope="col">Paymentreturn </th>
                                        <th scope="col">Profit</th> -->
                                        <th scope="col">Requestdate</th>
                                      <!--   <th scope="col">Returndate</th> -->
                                        <th scope="col">Phone number </th>
                                        <th scope="col">Method </th>
                                        <th scope="col">Status  </th>
                                        <th scope="col">View  </th>
                                        <th scope="col">Action</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                	
                                    @foreach($loanrequest as $ep)
                                    <tr>
                                        {{-- <th scope="row">{{$ep->id}}</th> --}}
                                        <td>{{$ep->name}}</td>
                                        <td>{{$ep->payment}}</td>
                                       <!--  <td>{{$ep->paymentreturn}}</td>
                                        <td>{{$ep->profit}}</td> -->
                                        <td>{{$ep->requestdate}}</td>
                                       <!--  <td>{{$ep->returndate}}</td> -->
                                        <td>{{$ep->phone_number}}</td>
                                        <td>{{$ep->method}}</td>
                                        @if($ep->status==0)
                                         <td>Under process</td>
                                        @elseif($ep->status==1)
                                         <td>Approved </td>
                                         @elseif($ep->status==2)
                                         <td>Unapproved </td>
                                     
                                        @endif

                                        <td><button type="button" class="btn btn-info view" data-bs-toggle="modal" data-id="{{$ep->id}}" data-bs-target="#exampleModal">
  <i class="fa fa-eye" style="font-size:20px;color:#fffffff"></i> 
</button></td>
<td><button type="button" class="btn btn-danger delete"  data-did="{{$ep->id}}" >
  <i class="fa fa-trash-o" style="font-size:20px;color:#fffffff"></i>
</button></td>
                                       

                                    </tr>

                                    @endforeach
                                   
                                </tbody>
                            </table>
                             {{ $loanrequest->links() }}  
                        </div>
                    </div>



<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
   
    

    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">View Request</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>

      <div class="d-flex align-items-center loader">
        <strong>Loading...</strong>
        <div class="spinner-border ml-auto" role="status" aria-hidden="true"></div>
      </div>
 <div class="all contencet"> 
      <div class="modal-body">
           
      <div class="card w-90 mb-3">
      <div class="card-body">
          <h5 class="card-title">Order id :-> <span id="betchid"> </span></h5>
 <ul class="list-group list-group-flush">
            <input type="hidden" id="id"> 
            <li class="list-group-item"><span > Name</span> <span class="right" id="name"> </span></li>
            <li class="list-group-item"><span >Payment </span> <span class="right" id="payment"> </span></li>
            <li class="list-group-item"><span > paymentreturn </span> <span class="right" id="paymentreturn"> </span></li>
             <li class="list-group-item"><span> profit </span> <span class="right" id="profit"> </span></li>
            <li class="list-group-item"><span> requestdate </span> <span class="right" id="requestdate"> </span></li>
            <li class="list-group-item"><span> returndate </span><span class="right" id="returndate"> </span> </li>
             <li class="list-group-item"><span> phone_number </span> <span class="right" id="phone_number"> </span></li>
            <li class="list-group-item"><span> method </span> <span class="right" id="method"> </span></li>
            <li class="list-group-item"><span id="status1"> status </span><span class="right" id="status"> </span> </li>
            <li class="list-group-item reasonlist"><span id="reason1"> reason </span><span class="right" id="reasoncheck"> </span> </li>
            
 </ul>
          
    </div>
    </div>


  </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-info approve"  id="approve">Approve</button>
        <button type="button" class="btn btn-primary unapprove" data-bs-toggle="modal" data-bs-target="#unapprove" data-bs-dismiss="modal">
        Unapprove
        </button>
        {{-- <button type="button" class="btn btn-info unapprove" id="unapprove">Unapprove</button> --}}
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        
      </div>
    </div>
  </div>
</div>
</div> 

<!-- epfo end  -->

{{-- unapprove --}}
    <!-- Modal -->
<div class="modal fade" id="unapprove" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Reason</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="mb-3">
         
          <input type="hidden" class="form-control rid" id="rid"></textarea>
        </div>

        <div class="mb-3">
          <label for="exampleFormControlTextarea1" class="form-label">Reason</label>
          <textarea class="form-control" id="reason" rows="3"></textarea>
        </div>
     </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="button" class="btn btn-primary unapprovesub">Submit</button>
      </div>
    </div>
  </div>
</div>

 @include('admin/footer'); 
            <!-- Footer Start -->
        
</body>

</html>