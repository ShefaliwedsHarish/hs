    @include('admin/header')
<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>

<!-- jQuery -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js" integrity="sha256-o9dE9Em5N5RvZUc0F8MFswU9BUcyeDJ1M8R6Ldceh1zq7zopOKyCmIciqH36V3nR" crossorigin="anonymous"></script>

<!-- Toastr CSS and JS -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>


<style>
  img.card-img-top {
    height: 300px;
}

a.btn.btn-danger {
    float: right;
    position: relative;
    margin-top: -133%;
    margin-right: -15px;
}
.col-4 {
    margin-top: 3%;
}


/*Loader */
.loader {
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid #3498db;
  width: 60px;
  height: 60px;
  -webkit-animation: spin 2s linear infinite; /* Safari */
  animation: spin 2s linear infinite;
  margin-left: 50%;
  display: none;
}

/* Safari */
@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.color {
    width: 40px;
    height: 40px;
}


</style>



<script> 

$(document).ready(function ()
{
  
function reload()
{
  location.reload(); 
}




$("#discount").on("keyup",function ()
{
 var productprice=$("#productprice").val(); 
 var discount=$("#discount").val(); 
 var percentage=productprice*discount/100;
 var total=productprice-percentage; 
 $("#total").val(total); 
}); 


$("#udiscount").on("keyup",function ()
{
 var productprice=$("#uproductprice").val(); 
 var discount=$("#udiscount").val(); 
 var percentage=productprice*discount/100;
 var total=productprice-percentage; 
 $("#utotal").val(total); 
}); 



$(".viewdata").on("click",function ()
{
 
  var id=$(this).data('id'); 
   $.ajax({
    headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
  url:"/viewproduct/"+id,
  type:"POST",
  success:function (d)
  {

    console.log(d); 
       var data=JSON.stringify(d);
       var data=JSON.parse(d);
       console.log(d);
      $("#productid").html(data.productid);
      $("#productid").html(data.productid);
      $("#originalprice").html(data.originalprice);
      $("#discount1").html(data.Discount);
      $("#total1").html(data.Total);
      $("#qty").html(data.Quanity);
      $("#des").html(data.description);
      $("#unit").html(data.Unit);
      $("#prname").html(data.productname);
      $(".card-img-top").attr('src',"dariy/"+data.Image); 
            
  }}); 

}); 




$(document).on("click",'.updatedata',function ()
{
  var id=$(this).data("updateid");
  $.ajax({
    headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
               
            url:'getprinting/'+id,
            type:'POST',
            success:function (d)
            {
                 var data=JSON.parse(d);  
                 console.log(data);
                 $("#uproduct_id").val(data.productid);
                 $("#uproductprice").val(data.originalprice);
                 $("#udiscount").val(data.Discount);
                 $("#utotal").val(data.Total);
                 $("#uqty").val(data.Quanity);
                 $("#udes").val(data.description);
                 $("#unit").val(data.Unit);
                 $("#uProductname").val(data.productname);
                 var unit=data.Unit;
                 if(unit=="Gram")
                 {
                      $("#Gram").attr('checked', true);
                 }
                 else if(unit=="Kg")
                 {
                      $("#Kg").attr('checked', true);
                 }
                 else 
                 {
                      $("#Bottle").attr('checked', true);
                 }
            }
  }); 
});
// DELETE image ajax
 $(document).on("click",".delete_image",function ()
 {
   var id=$(this).data("did"); 
   var data=this; 

   $.ajax({
             headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
           url:'/deletesize/'+id,
           type:'post',
           success:function(d)
           {
                    if(d==1)
                  {
                        
               window.location.href='/dairyproduct' 
                  } 
           }


   })
 });

 // thumnail image
 $(document).on("click",".check",function()
 {
      $(".loader").show(); 
      $(".modal-footer").hide(); 
     var id=$(this).data("id");
     $.ajax({
             headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
           url:'/selectimage/'+id,
           type:'post',
           success:function(d)
           {
             window.location.href='/dairyproduct' ;
           }


   })


 }); 

 $("#addproduct").submit(function (e)
 {
e.preventDefault(); 
var formData =new FormData(this); 

    $.ajax({
       headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
    url:'/saveprinting',
    type:'POST',
    processData: false,
    contentType: false,
    data:formData,
    success:function (d){
    var data=JSON.parse(d); 
    if(data.status==true){
      $('#sitesetting').modal('hide');
      toastr.success(data.message, { timeOut: 9500 });
      const myTimeout = setTimeout(reload, 5000);
     }
    else {
             toastr.error(data.message);
     }

  }
  }); 
 }); 

 $(document).on("click",".delete",function ()
 {
   var id=$(this).data("del");
   $.ajax({
    headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            url:'/deleteprinting/'+id,
            type:'post',
            success:function (d)
            {
             var data=JSON.parse(d); 
             if(data.status==true){
                  
                    toastr.success(data.message);
                    const myTimeout = setTimeout(reload, 5000);
                  }
            }
       });
 }); 

$("#updateprinting").on("submit",function (e)
{
  e.preventDefault(); 
  var productid=$("#uproduct_id").val(); 
 var data=$(this).serialize();

$.ajax({
    headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            url:'/updateprinting/'+productid,
            type:'post',
            data:data,
            success:function (d)
            {
             var data=JSON.parse(d); 
             if(data.status==true){
                  
                    toastr.success(data.message);
                    $("#update").modal('hide');
                    const myTimeout = setTimeout(reload, 5000);
                  }
            }
       }); 

});

$(document).on("click",".size",function ()
{
 var pri=$(this).data("addim"); 
 $("#prisize").val(pri); 
 $.ajax({
    headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
  url:"/viewsize/"+pri,
  type:"POST",
  success:function (d)
  {
      var data=JSON.parse(d); 
      console.log(data); 
      var table=''; 
       $.each(data,function (key,value)
          {
                table+="<tr class='image'>"; 
                table+="<td>"+value.size+"</td>";
                table+="<td>"+value.quanitity+"</td>";
                table+="<td><div class='color' style='background-color:"+value.color+"'> </div></td>";
                table+="<td>"+value.Total+"</td>";
                table+="<td> <button type='button' class='btn btn-danger delete_image' data-did='"+value.id+"'>Delete</button>";
                table+="</tr>"; 
          });    
          $(".img").html(table);     
   }});


}); 


$("#size").on("submit",function (e)
{
e.preventDefault(); 
var data=$(this).serialize(); 
$.ajax({

        url:'/addsize',
        type:'post',
        data:data,
        success:function (d)
        {
             var data=JSON.parse(d); 
             if(data.status==true){
                  
                    toastr.success(data.message);
                    $("#addsize").modal('hide');
                    const myTimeout = setTimeout(reload, 5000);
                  } 
        }

});



}); 





}); 


</script>


<body> 
  <br> 

 <ul class="p-0 m-0" style="list-style: none;">
        @foreach($errors->all() as $error)
        <li class="text-danger">{{$error}}</li>
        @endforeach
    </ul>

  <div class="container" style="background-color:#F0F3F4"> 
    <br> 
    <meta name="csrf-token" content="{{ csrf_token() }}">
    
       <div class="card" style="width: 90%;">   
        <div class="card-body">
      

  <h5 style="float:left"> Printing Product  </h5> 
     <button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#sitesetting"style="margin-left:70%">
 <i class="bi bi-plus-square"></i>  Add
</button>
    <br> 
    <br> 

<div class="row">
  <div class="col" style="width:100%; height:482px; overflow-y: scroll"> 
<table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">Product Id</th>
      <th scope="col">Product Name</th>
      <th scope="col">Prouduct Price</th>
      <th scope="col">Discount</th>
      <th scope="col">Qty </th>
      <th scope="col">Total </th>
      <th scope="col">Size</th> 
      <th scope="col">View </th>
      <th scope="col" style="text-align:center">Acton </th>
    </tr>
  </thead>
  <tbody>
    @foreach($products as $product)
    <tr>
      <td>{{$product->productid}}</td>
      <td>{{$product->productname}}</td>
      <td>{{$product->originalprice}}</td>
      <td>{{$product->Discount}}</td>
      <td>{{$product->total_quanitity}}</td>
      <td>{{$product->Total}}</td>
      <td><button type="button" class="btn btn-secondary size" data-bs-toggle="modal"
         data-bs-target="#addsize" data-addim="{{$product->productid}}" data-viewimage="{{$product->id}}"><i class="bi bi-plus-square" style="font-size:24px"></i></td>

      <td>
        <button class="btn btn-primary viewdata" data-bs-target="#view" data-bs-toggle="modal" data-id="{{$product->id}}"><i class="fa fa-eye" style="font-size:24px"></i></button></td>
      <td><pre> <button type="button" class="btn btn-danger delete" data-del="{{$product->productid}}"> <i class="fa fa-trash" style="font-size:24px"></i> </button> <button type="button" class="btn btn-info updatedata" data-bs-toggle="modal" data-bs-target="#update" data-updateid="{{$product->productid}}"><i class="fas fa-edit" style="font-size:24px"></i></button> <button type="button" class="btn btn-secondary image" data-bs-toggle="modal" data-bs-target="#addimage" data-addim="{{$product->productid}}" data-viewimage="{{$product->id}}"><i class=" fas fa-images" style="font-size:24px"></i></pre></td>
    </tr>
    @endforeach


  </tbody>
</table>
<div class="pagination">
        {{ $products->links() }}
</div>
</div>
</div>




</div>
</div>
   <br> <br> <br>  <br> <br> <br> 
</div>



<!-- add model -->
<div class="modal fade" id="sitesetting" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="General">Add Product </h1> 
        
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">  
     
       
      <form  method="POST" enctype="multipart/form-data" id="addproduct"> 
      @csrf 
       <div class="row">
      <div class="col-6">  
      <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Product Id</label>
    <input type="text" class="form-control" id="exampleInputPassword1" name="productid" value="{{old('productid')}}">
  </div>
</div>
<div class="col-6">  
      <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Product Name</label>
    <input type="text" class="form-control" id="productname" name="Productname" value="{{old('Productname')}}">
  </div>
</div>
</div>


 <div class="row">
      <div class="col-6">  
      <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Product Price</label>
    <input type="text" class="form-control" id="productprice" name="productprice"value="{{old('productprice')}}">
  </div>
</div>
<div class="col-6">  
      <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Discount</label>
    <input type="text" class="form-control" id="discount" name="discount"value="{{old('discount')}}">
  </div>
</div>
</div>


    
     <div class="row">
      <div class="col-6">  
      <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Total Price</label>
    <input type="text" class="form-control" id="total" name="total"readonly="" value="{{old('total')}}">
  </div>
</div>

<div class="col-6">  
  <div class="mb-3">
<label for="exampleInputPassword1" class="form-label">Description </label>
<textarea class="form-control" id="text" name="des" value="{{old('des')}}"> </textarea>
</div>
</div>

</div>

     </div>
    <br> 

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Submit" id="run">


</form>
</div></div>
      </div>
    </div>
  </div>
</div>
</div>


<!-- View  -->

<div class="modal fade" id="view" aria-hidden="true" aria-labelledby="exampleModalToggleLabel2" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalToggleLabel2">View Data </h1>

        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
       <div class="data" id="data"> 
       </div>
      <div class="row"> 
       <div class="col-6">
        <div class="card" style="width: 18rem;">
  <img class="card-img-top" src=".../30px30/" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title"> Product Name  : <span id="prname">Crud </span> </h5>
  </div>
</div>
       </div>
  <div class="col-3">
        <div class="card" style="width: 15rem;border:none">
  <div class="card-body">
  <table class="table table-striped">
  <tr>
       <th scope="col">Product Id</th>
       <td id="productid"> </td>
  </tr>
  
  <tr>
       <th scope="col">Originalprice</th>
       <td id="originalprice"> </td>
  </tr>

  <tr>
       <th scope="col">Discount</th>
       <td id="discount1"> </td>
  </tr>

  <tr>
       <th scope="col">Total</th>
       <td id="total1"> </td>
  </tr>

   <tr>
       <th scope="col">Quanity</th>
       <td id="qty"> </td>
  </tr>

   <tr>
       <th scope="col">Unit</th>
       <td id="unit"> </td>
  </tr>

  <tr>
       <th scope="col" colspan="2">Description</th>
  </tr>
 <td id="des"> </td>
      </table>
  </div>
</div>
       </div>
</div>
      </div>
      <div class="modal-footer">     
      </div>
    </div>



  </div>
</div>



<!-- Update modal -->
<div class="modal fade" id="update" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Update Data</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
 <div class="modal-body">   
    <form  method="POST" enctype="multipart/form-data" id="updateprinting"> 
    @csrf 
       <div class="row">
            <div class="col-6">  
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Product Id</label>
                <input type="text" class="form-control" id="uproduct_id" name="productid" readonly="">
            </div>
            </div>
            <div class="col-6">  
            <div class="mb-3">
                <label for="exampleInputPassword1" class="form-label">Product Name</label>
                <input type="text" class="form-control" id="uProductname" name="Productname" >
            </div>
            </div>
       </div>
 <div class="row">
              <div class="col-6">  
              <div class="mb-3">
                    <label for="exampleInputPassword1" class="form-label">Product Price</label>
                    <input type="text" class="form-control" id="uproductprice" name="productprice"value="{{old('productprice')}}">
              </div>
              </div>
              <div class="col-6">  
              <div class="mb-3">
                  <label for="exampleInputPassword1" class="form-label">Discount</label>
                  <input type="text" class="form-control" id="udiscount" name="discount"value="{{old('discount')}}">
              </div>
              </div>
  </div>
  <div class="row">
      <div class="col-6">  
      <div class="mb-3">
          <label for="exampleInputPassword1" class="form-label">Total Price</label>
          <input type="text" class="form-control" id="utotal" name="total"readonly="" value="{{old('total')}}">
      </div>
      </div>
       <div class="col-6">  
       <div class="mb-3">
            <label for="exampleInputPassword1" class="form-label">Quanity</label>
            <input type="text" class="form-control" id="uqty" name="quanity" value="{{old('Productname')}}">
         </div>
         </div>
  </div>
<br> 
   <div class="row"> 

      <div class="col-6">  
      <div class="mb-3">
           <label for="exampleInputPassword1" class="form-label">description </label>
           <textarea class="form-control" id="udes" name="des" value="{{old('des')}}"> </textarea>
       </div>
       </div>
       <div class="col-6"> 
            <label for="exampleInputPassword1" class="form-label" style="margin-left:30%">Unit </label><br> <br> 
       <div class="form-check form-check-inline">
           <input class="form-check-input" type="radio" name="unit" id="Gram" value="Gram">
           <label class="form-check-label" for="inlineRadio1">Gram</label>
        </div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="unit" id="Kg" value="Kg">
  <label class="form-check-label" for="inlineRadio2">KG</label>
</div>
<div class="form-check form-check-inline">
  <input class="form-check-input" type="radio" name="unit" id="Bottle" value="Bottle" >
  <label class="form-check-label" for="inlineRadio3">Bottle </label>
</div>


       </div>
     </div>
    <br> 





      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Update">
        </form>
      </div>
    </div>
  </div>
</div>





{{-- add size --}}
<div class="modal fade" id="addsize" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="staticBackdropLabel">Add Image </h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
    

 <form method="POST" id="size" enctype="multipart/form-data">
  @csrf
  <div class="mb-3">
       <input type="hidden" class="form-control" id="prisize" aria-describedby="emailHelp" name="productid">
  </div>

  <form>
    <div class="mb-3">
      <label  class="form-label">Size</label>
      <select class="form-control" name="size">
      <option>XS (Extra Small) </option> 
      <option> M (Medium)</option>   
      <option>XS (Extra Small) </option> 
      <option>L (Large) </option> 
      <option>XL (Extra Large) </option>  
      </select> 
   </div>
   <div class="row">
    <div class="col-md-6 mb-4">

      <div class="form-outline datepicker">
        <label for="exampleDatepicker1" class="form-label">Quantity</label>
        <input type="text" class="form-control" id="quantity" name="quantity"/>
       </div>

    </div>
    <div class="col-md-6 mb-4">
      <label for="exampleDatepicker1" class="form-label">color</label>
      <input type="color" id="favcolor" class="form-control" name="color" value="#ff0000">   
    </div>
  </div>
    


<input type="submit" class="btn btn-success" value="Add">
 <div class="loader"></div>
</form>

      </div>
      <div class="modal-footer">
       <table class="table">
  <thead>
    <tr>
      <th scope="col">Size</th>
      <th scope="col">Quantity</th>
      <th scope="col">Color</th>
      <th scope="col">Total</th>
      <th scope="col">Action </th>
    </tr>
  </thead>
  <tbody class="img">
     <td> 
     </tbody>
    
</table>
</div>
</div>
</div>
</div>
