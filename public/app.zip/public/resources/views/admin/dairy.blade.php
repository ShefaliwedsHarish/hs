    @include('admin/header')
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>


<style>
	img.card-img-top {
    height: 300px;
}



a.btn.btn-danger {
    float: right;
    position: relative;
    margin-top: -133%;
    margin-right: -15px;
}

.col-4 {
    margin-top: 3%;
}





/*Loader */

.loader {

  border: 16px solid #f3f3f3;

  border-radius: 50%;

  border-top: 16px solid #3498db;

  width: 60px;

  height: 60px;

  -webkit-animation: spin 2s linear infinite; /* Safari */

  animation: spin 2s linear infinite;

  margin-left: 50%;

  display: none;

}



/* Safari */

@-webkit-keyframes spin {

  0% { -webkit-transform: rotate(0deg); }

  100% { -webkit-transform: rotate(360deg); }

}



@keyframes spin {

  0% { transform: rotate(0deg); }

  100% { transform: rotate(360deg); }

}





</style>




<?php

$dariy=config('path.dairy')

?>
<script> 

$(document).ready(function ()
{
$("#discount").on("keyup",function ()
{
 var productprice=$("#productprice").val(); 
 var discount=$("#discount").val(); 
 var percentage=productprice*discount/100;
 var total=productprice-percentage; 
 $("#total").val(total); 
}); 



$("#udiscount").on("keyup",function ()
{
 var productprice=$("#uproductprice").val(); 
 var discount=$("#udiscount").val(); 
 var percentage=productprice*discount/100;
 var total=productprice-percentage; 
 $("#utotal").val(total); 
}); 


$(".viewdata").on("click",function ()
{
 var id=$(this).data('id'); 
  $.ajax({
   headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
       },
  url:"/viewdairy/"+id,
  type:"POST",
  success:function (d)
  {
    console.log(d);
       //var data=JSON.stringify(d);
       var data=JSON.parse(d);
       console.log(d);
      $("#productid").html(data.productid);
      $("#productid").html(data.productid);
      $("#originalprice").html(data.originalprice);
      $("#discount1").html(data.Discount);
      $("#total1").html(data.Total);
      $("#qty").html(data.Quanity);
      $("#des").html(data.description);
      $("#unit").html(data.Unit);

      $("#prname").html(data.productname);
      $(".card-img-top").attr('src', "public/dairy/" + data.Image);

  }}); 
}); 

$(".image").on("click",function ()
{

   var id=$(this).data('addim');
    $("#idimage").val(id);
    var value;
    $.ajax({
    headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },

  url:"/viewimage/"+id,
  type:"POST",
  success:function (d)
  {
      var data=JSON.parse(d); 
      console.log(data); 
      var table=''; 
       $.each(data,function (key,value)
          {
                table+="<tr class='image'>"; 
                table+="<td><img src='{{$dairy}}/"+value.Image+"' height='200px' width='200px'></td>";
                if(value.Selectimage==1)
                { 
                table+="<td> <input type='checkbox' class='check' data-id='"+value.id+"' checked> </td>"; 
                }
                else
                {
                table+="<td> <input type='checkbox' class='check' data-id='"+value.id+"'> </td>"; 
                }
                table+="<td> <button type='button' class='btn btn-danger delete_image' data-did='"+value.id+"'>Delete</button>";
                table+="</tr>"; 
          });    

          $(".img").html(table);     

   }}); 

}); 



$(".updatedata").on("click",function ()

{

  var id=$(this).data("updateid");

  $.ajax({

    headers: {

            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

        },

               

            url:'getproduct/'+id,

            type:'POST',

            success:function (d)

            {

                 var data=JSON.parse(d);  

                 console.log(data);

                 $("#uproduct_id").val(data.productid);

                 $("#uproductprice").val(data.originalprice);

                 $("#udiscount").val(data.Discount);

                 $("#utotal").val(data.Total);

                 $("#uqty").val(data.Quanity);

                 $("#udes").val(data.description);

                 $("#unit").val(data.Unit);

                 $("#uProductname").val(data.productname);

                 var unit=data.Unit;

                 if(unit=="Gram")

                 {

                      $("#Gram").attr('checked', true);

                 }

                 else if(unit=="Kg")

                 {

                      $("#Kg").attr('checked', true);

                 }

                 else 

                 {

                      $("#Bottle").attr('checked', true);

                 }

            }

  }); 

});

// DELETE image ajax

 $(document).on("click",".delete_image",function ()

 {

   var id=$(this).data("did"); 

   var data=this; 



   $.ajax({

             headers: {

            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

        },

           url:'/deleteimage/'+id,

           type:'post',

           success:function(d)

           {

                    if(d==1)

                  {

                        

               window.location.href='/dairyproduct' 

                  } 

           }





   })

 });



 // thumnail image

 $(document).on("click",".check",function()

 {

      $(".loader").show(); 

      $(".modal-footer").hide(); 

     var id=$(this).data("id");

     $.ajax({

             headers: {

            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

        },

           url:'/selectimage/'+id,

           type:'post',

           success:function(d)

           {

             window.location.href='/dairyproduct' ;

           }





   })





 }); 





}); 





</script>





<body> 

	<br> 



 <ul class="p-0 m-0" style="list-style: none;">

        @foreach($errors->all() as $error)

        <li class="text-danger">{{$error}}</li>

        @endforeach

    </ul>



	<div class="container" style="background-color:#F0F3F4"> 

		<br> 

    <meta name="csrf-token" content="{{ csrf_token() }}">

    

       <div class="card" style="width: 90%;"> 	

        <div class="card-body">

     	



  <h5 style="float:left"> Add Dairy Product  </h5> 

  	 <button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#sitesetting"style="margin-left:70%">

 <i class="bi bi-plus-square"></i>  Add

</button>

  	<br> 

    <br> 



<div class="row">

  <div class="col" style="width:100%; height:332px; overflow-y: scroll"> 

<table class="table table-striped">

  <thead>

    <tr>

      <th scope="col">Product Id</th>

      <th scope="col">Product Name</th>

      <th scope="col">Prouduct Price</th>

      <th scope="col">Discount</th>

      <th scope="col">Total </th>

      <th scope="col">View </th>

      <th scope="col" style="text-align:center">Acton </th>

    </tr>

  </thead>

  <tbody>

    @foreach($dairy as $dairy1)

    <tr>

      <td>{{$dairy1->productid}}</td>

      <td>{{$dairy1->productname}}</td>

      <td>{{$dairy1->originalprice}}</td>

      <td>{{$dairy1->Discount}}</td>

      <td>{{$dairy1->Total}}</td>



      <td>

        <button class="btn btn-primary viewdata" data-bs-target="#view" data-bs-toggle="modal" data-id="{{$dairy1->id}}"><i class="fa fa-eye" style="font-size:24px"></i></button></td>

      <td><pre> <a href="/delete/{{$dairy1->productid}}/data"><button type="button" class="btn btn-danger"> <i class="fa fa-trash" style="font-size:24px"></i> </button></a> <button type="button" class="btn btn-info updatedata" data-bs-toggle="modal" data-bs-target="#update" data-updateid="{{$dairy1->productid}}"><i class="fas fa-edit" style="font-size:24px"></i></button> <button type="button" class="btn btn-secondary image" data-bs-toggle="modal" data-bs-target="#addimage" data-addim="{{$dairy1->productid}}" data-viewimage="{{$dairy1->id}}"><i class=" fas fa-images" style="font-size:24px"></i></pre></td>

    </tr>

    @endforeach





  </tbody>

</table>

<div class="pagination">

        {{ $dairy->links() }}

</div>

</div>

</div>









</div>

</div>

   <br> <br> <br>  <br> <br> <br> 

</div>







<!-- add model -->

<div class="modal fade" id="sitesetting" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

  <div class="modal-dialog modal-lg">

    <div class="modal-content">

      <div class="modal-header">

        <h1 class="modal-title fs-5" id="General">Add Product </h1> 

        

        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

      </div>

      <div class="modal-body">  

     

       

      <form action="{{route('savedairyproduct')}}" method="POST" enctype="multipart/form-data"> 

      @csrf 

       <div class="row">

      <div class="col-6">  

      <div class="mb-3">

    <label for="exampleInputPassword1" class="form-label">Product Id</label>

    <input type="text" class="form-control" id="exampleInputPassword1" name="productid" value="{{old('productid')}}">

  </div>

</div>

<div class="col-6">  

      <div class="mb-3">

    <label for="exampleInputPassword1" class="form-label">Product Name</label>

    <input type="text" class="form-control" id="productname" name="Productname" value="{{old('Productname')}}">

  </div>

</div>

</div>





 <div class="row">

      <div class="col-6">  

      <div class="mb-3">

    <label for="exampleInputPassword1" class="form-label">Product Price</label>

    <input type="text" class="form-control" id="productprice" name="productprice"value="{{old('productprice')}}">

  </div>

</div>

<div class="col-6">  

      <div class="mb-3">

    <label for="exampleInputPassword1" class="form-label">Discount</label>

    <input type="text" class="form-control" id="discount" name="discount"value="{{old('discount')}}">

  </div>

</div>

</div>





    

     <div class="row">

      <div class="col-6">  

      <div class="mb-3">

    <label for="exampleInputPassword1" class="form-label">Total Price</label>

    <input type="text" class="form-control" id="total" name="total"readonly="" value="{{old('total')}}">

  </div>

</div>

<div class="col-6">  

      <div class="mb-3">

    <label for="exampleInputPassword1" class="form-label">Quanity</label>

    <input type="text" class="form-control" id="total" name="quanity" value="{{old('Productname')}}">

  </div>

</div>

</div>



<br> 

   <div class="row"> 



      <div class="col-6">  

      <div class="mb-3">

    <label for="exampleInputPassword1" class="form-label">description </label>

    <textarea class="form-control" id="text" name="des" value="{{old('des')}}"> </textarea>

  </div>

</div>









       <div class="col-6"> 

        <label for="exampleInputPassword1" class="form-label" style="margin-left:30%">Unit </label><br> <br> 

        <div class="form-check form-check-inline">

  <input class="form-check-input" type="radio" name="unit" id="inlineRadio1" value="Gram">

  <label class="form-check-label" for="inlineRadio1">Gram</label>

</div>

<div class="form-check form-check-inline">

  <input class="form-check-input" type="radio" name="unit" id="inlineRadio2" value="Kg">

  <label class="form-check-label" for="inlineRadio2">KG</label>

</div>

<div class="form-check form-check-inline">

  <input class="form-check-input" type="radio" name="unit" id="inlineRadio3" value="Bottle" >

  <label class="form-check-label" for="inlineRadio3">Bottle </label>

</div>





       </div>

     </div>

    <br> 



      <div class="modal-footer">

        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

        <input type="submit" class="btn btn-primary" value="Submit" id="run">





</form>

</div></div>

      </div>

    </div>

  </div>

</div>

</div>





<!-- View  -->



<div class="modal fade" id="view" aria-hidden="true" aria-labelledby="exampleModalToggleLabel2" tabindex="-1">

  <div class="modal-dialog modal-lg">

    <div class="modal-content">

      <div class="modal-header">

        <h1 class="modal-title fs-5" id="exampleModalToggleLabel2">View Data </h1>



        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

      </div>

      <div class="modal-body">

       <div class="data" id="data"> 

       </div>

      <div class="row"> 

       <div class="col-6">

        <div class="card" style="width: 18rem;">

  <img class="card-img-top" src="../30px30/" alt="Card image cap">

  <div class="card-body">

    <h5 class="card-title"> Product Name  : <span id="prname">Crud </span> </h5>

  </div>

</div>

       </div>

  <div class="col-3">

        <div class="card" style="width: 15rem;border:none">

  <div class="card-body">

  <table class="table table-striped">

  <tr>

       <th scope="col">Product Id</th>

       <td id="productid"> </td>

  </tr>

  

  <tr>

       <th scope="col">Originalprice</th>

       <td id="originalprice"> </td>

  </tr>



  <tr>

       <th scope="col">Discount</th>

       <td id="discount1"> </td>

  </tr>



  <tr>

       <th scope="col">Total</th>

       <td id="total1"> </td>

  </tr>



   <tr>

       <th scope="col">Quanity</th>

       <td id="qty"> </td>

  </tr>



   <tr>

       <th scope="col">Unit</th>

       <td id="unit"> </td>

  </tr>



  <tr>

       <th scope="col" colspan="2">Description</th>

  </tr>

 <td id="des"> </td>

      </table>

  </div>

</div>

       </div>

</div>

      </div>

      <div class="modal-footer">     

      </div>

    </div>

  </div>

</div>



<!-- add image  -->



<div class="modal fade" id="addimage" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">

  <div class="modal-dialog modal-lg">

    <div class="modal-content">

      <div class="modal-header">

        <h1 class="modal-title fs-5" id="staticBackdropLabel">Add Image </h1>

        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

      </div>

      <div class="modal-body">

    



 <form action="/addimage"method="POST" enctype="multipart/form-data">

  @csrf

  <div class="mb-3">

       <input type="hidden" class="form-control" id="idimage" aria-describedby="emailHelp" name="productid">

  </div>



  <div class="mb-3">

    <label for="exampleInputPassword1" class="form-label">Image</label>

    <input type="file" class="form-control" id="exampleInputPassword1" name="file">

  </div>

<input type="submit" class="btn btn-success" value="Add">

 <div class="loader"></div>

</form>



      </div>

      <div class="modal-footer">

       <table class="table">

  <thead>

    <tr>

      <th scope="col">Image</th>

      <th scope="col">Thumbline</th>

      <th scope="col">Action </th>

    </tr>

  </thead>

  <tbody class="img">

     <td> 

     </tbody>

    

</table>

</div>

</div>

</div>

</div>





<!-- Update modal -->

<div class="modal fade" id="update" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

  <div class="modal-dialog modal-lg">

    <div class="modal-content">

      <div class="modal-header">

        <h1 class="modal-title fs-5" id="exampleModalLabel">Update Data</h1>

        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

      </div>

 <div class="modal-body">   

    <form action="{{route('updatedairy')}}" method="POST" enctype="multipart/form-data"> 

    @csrf 

       <div class="row">

            <div class="col-6">  

            <div class="mb-3">

                <label for="exampleInputPassword1" class="form-label">Product Id</label>

                <input type="text" class="form-control" id="uproduct_id" name="productid" readonly="">

            </div>

            </div>

            <div class="col-6">  

            <div class="mb-3">

                <label for="exampleInputPassword1" class="form-label">Product Name</label>

                <input type="text" class="form-control" id="uProductname" name="Productname" >

            </div>

            </div>

       </div>

 <div class="row">

              <div class="col-6">  

              <div class="mb-3">

                    <label for="exampleInputPassword1" class="form-label">Product Price</label>

                    <input type="text" class="form-control" id="uproductprice" name="productprice"value="{{old('productprice')}}">

              </div>

              </div>

              <div class="col-6">  

              <div class="mb-3">

                  <label for="exampleInputPassword1" class="form-label">Discount</label>

                  <input type="text" class="form-control" id="udiscount" name="discount"value="{{old('discount')}}">

              </div>

              </div>

  </div>

  <div class="row">

      <div class="col-6">  

      <div class="mb-3">

          <label for="exampleInputPassword1" class="form-label">Total Price</label>

          <input type="text" class="form-control" id="utotal" name="total"readonly="" value="{{old('total')}}">

      </div>

      </div>

       <div class="col-6">  

       <div class="mb-3">

            <label for="exampleInputPassword1" class="form-label">Quanity</label>

            <input type="text" class="form-control" id="uqty" name="quanity" value="{{old('Productname')}}">

         </div>

         </div>

  </div>

<br> 

   <div class="row"> 



      <div class="col-6">  

      <div class="mb-3">

           <label for="exampleInputPassword1" class="form-label">description </label>

           <textarea class="form-control" id="udes" name="des" value="{{old('des')}}"> </textarea>

       </div>

       </div>

       <div class="col-6"> 

            <label for="exampleInputPassword1" class="form-label" style="margin-left:30%">Unit </label><br> <br> 

       <div class="form-check form-check-inline">

           <input class="form-check-input" type="radio" name="unit" id="Gram" value="Gram">

           <label class="form-check-label" for="inlineRadio1">Gram</label>

        </div>

<div class="form-check form-check-inline">

  <input class="form-check-input" type="radio" name="unit" id="Kg" value="Kg">

  <label class="form-check-label" for="inlineRadio2">KG</label>

</div>

<div class="form-check form-check-inline">

  <input class="form-check-input" type="radio" name="unit" id="Bottle" value="Bottle" >

  <label class="form-check-label" for="inlineRadio3">Bottle </label>

</div>





       </div>

     </div>

    <br> 











      </div>

      <div class="modal-footer">

        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

        <input type="submit" class="btn btn-primary" value="Update">

        </form>

      </div>

    </div>

  </div>

</div>