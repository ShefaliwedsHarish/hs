@include('folder/header'); 
@include('folder/link');

<?php
$manage=config('path.about');


?> 



<br> <br> 

<div class="ch" style="width:100%;height:70px;background-color:white;margin-top:8px"> 
<h1 style="text-align:center">   Online  Serive  <hr style="width:20%;margin-left:40%">  </h1> 

</div> 

<br> 

<div class="per" style="width:50%;margin-left:42%">
<br> <br> <br> 
<p>  <a href="/epfoform"> <button type="button" class="btn btn-secondary" id="epfo" value="EPFO">EPFO </button> </a> &nbsp; &nbsp; 
 <a href="/itr_form"> <button type="button" class="btn btn-info" id="itr" value="ITR">ITR</button> </a> &nbsp; &nbsp;  
 <a href="/online2"><button type="button" class="btn btn-warning" id="online" value="Online Form">Online Form </button> </p> </a>
</div> 


<div class="part2" style="background-color:black"> 
 <h1 style="color:white;text-align:center" id="act"> Online   </h1> 
</div> 



<div class="form" > 
<img src="{{$manage}}/onlinecheck.jpg"style="width:100%"> 
<img src="{{$manage}}/logo.png" style=" width:120px;position:relative; margin-top:-107%;margin-left:45%">
<img src="{{$manage}}/mylife.png" style=" width:120px;position:relative; margin-top:-107%;float:right"> 
<p> <img src="{{$manage}}/h.png" style=" width:120px; height:110px; position:relative; margin-top:-107%;"></p> 
<div> 



