@include('folder/header'); 
@include('folder/link');


<br> <br> 
<div class="ch" style="position:fixed;width:100%;height:70px;background-color:white;margin-top:8px"> 
<h1 style="text-align:center">   Online  Serive  <hr style="width:20%;margin-left:40%">  </h1> 
</div> 
<br> 
<div class="per" style="width:50%;margin-left:42%">
<br> <br> <br> 
<p>  <a href="/epfoform"> <button type="button" class="btn btn-secondary" id="epfo" value="EPFO">EPFO </button> </a> &nbsp; &nbsp; 
  <a href="/itr_form"> <button type="button" class="btn btn-info" id="itr" value="ITR">ITR</button> </a>  &nbsp; &nbsp;  
<a href="/online2"><button type="button" class="btn btn-warning" id="online" value="Online Form">Online Form </button></a> </p> 
</div> 

<div class="part2" style="background-color:black"> 
 <h1 style="color:white;text-align:center" id="act"> Online Form   </h1> 
</div>  
<div class="container" style="background-color:#63F416; border:7px solid green">


 <form>
      <div class="modal-body">


      
      <div  class="row"> 
    <div class="col-6"> 

<div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Name</label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required="">
   
  </div>

    </div> 
    <div class="col-6"> 

<div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Email </label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required="">
   
  </div>
             </div> 
    </div> 
      
  


        <div  class="row"> 
    <div class="col-6"> 

<div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Phone Number </label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required="">
   
  </div>

    </div> 
    <div class="col-6"> 

<div class="mb-3">
    <label for="exampleInputEmail1" class="form-label"> Form Name    </label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required="">
   
  </div>
             </div> 
    </div> 

    <h5> When our team  fill your form. Then our team will call you.  <input type="submit"  class="btn btn-success" name="sb" style="margin-left:45%"> </h5>

             

</form> 
        










