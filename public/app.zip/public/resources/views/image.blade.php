@php
    function show($id)
    {
    switch($id)
    {
        case 1:
        echo "<h1> /craousal</h1>"; 
        break; 
    }
}

@endphp