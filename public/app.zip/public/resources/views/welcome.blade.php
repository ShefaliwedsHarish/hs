     @include('folder/header');

     @include('folder/link');
     
     <?php
                          $craousal2 = config('path.craousal'); // Assuming 'path.user' is the correct configuration key
                        //   $userProfile = Auth::user()->User_profile;
                      ?>

     @php

     //$craousal2='craousal'; 

     $route = config('path.review');



@endphp











     <html lang="en">







     <head>



         <meta charset="utf-8" />



         <title>HSGroup</title>



         <link rel="icon" type="image/x-icon"

             href="https://images.pexels.com/photos/631986/pexels-photo-631986.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1">



         <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1" />



         <!-- Link Swiper's CSS -->



         <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />







         <!-- Demo styles -->



         <style>

             html,

            body {

                 position: relative;

                 height: 100%;

             }







             body {

                 background: #eee;

                 font-family: Helvetica Neue, Helvetica, Arial, sans-serif;

                 font-size: 14px;

                 color: #000;

                 margin: 0;

                 padding: 0;

             }







             .swiper {

                 width: 100%;

                 height: 75%;

                 margin-top: 40px;

                 border: 7px solid green;

             }







             .swiper-slide {

                 background-position: center;

                 background-size: cover;

             }







             .swiper-slide img {

                 display: block;

                 width: 100%;

             }

            

                 







             @media only screen and (max-width: 909px)  {

                 .swiper-slide img {

                     height: 500px;

                }



                 div#swiper-wrapper-f83f50755261f56c {

                     width: 100%;

                     height: 174px;

                 }



                 .swiper-pagination.swiper-pagination-bullets.swiper-pagination-horizontal {

                     display: none;

                 }



             }





             

             @media only screen and (max-width: 1360px) {



              

                 .col-8 {

                     flex: 0 0 auto;

                     width: 100%;

                 }



                 .col-4 {

                     width: 100%;

                 }



              



             }

         </style>

     </head>







     <body>

         <!-- Swiper -->

         <div class="swiper mySwiper">

             <div class="swiper-wrapper">

                 @foreach ($cra as $craousal)

                     <div class="swiper-slide">

                         <img src="{{$craousal2.'/'.$craousal->images }}" />

                     </div>

                 @endforeach

             </div>







             <div class="swiper-pagination"></div>



         </div>







         <div class="part2" style="background-color:black;margin-top:5px">







             <h1 style="color:white;text-align:center"> REACH US </h1>



         </div>







         <div class="part3" style="margin-top:5px;border:7px solid green">



             <div class="container-fluid">



                 <div class="row">



                     <div class="col-8" style="border:7px solid white">



                         <iframe src="{{ $contact->Ifram }}" width="100%" height="450" style="border:0;"

                             allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>



                     </div>



                     <div class="col-4" style="border:7px solid white">



                         <div class="contact shadow"

                             style="width:60%;margin-left:10%;background-color:white;position:relative">



                             <h4 style="margin-top:40px;margin-left:10%"><b> Call Us</b> </h4>



                             <font style="margin-left:10px"> <a href="{{ $contact->Phone_number1 }}"

                                     style="text-decoration:none;color:black"> <i class="fa fa-phone" aria-hidden="true"

                                         style="font-size:24px"></i><span style="font-size:15px"> +91

                                         {{ $contact->Phone_number1 }} </span></a> <br> <br></font>



                             <font style="margin-left:10px"> <a href="{{ $contact->Phone_number2 }}"

                                     style="text-decoration:none;color:black"> <i class="fa fa-phone" aria-hidden="true"

                                         style="font-size:24px"></i><span style="font-size:15px"> +91

                                         {{ $contact->Phone_number2 }} </span></a> <br> <br></font>



                         </div>











                         <div class="contact shadow"

                             style="width:60%;margin-left:10%;background-color:white;position:relative">



                             <h4 style="margin-top:40px;margin-left:10%"><b> Follow Us</b> </h4>



                             <font style="margin-left:10px"> <a href="{{ $contact->Twitter }}"

                                     style="text-decoration:none;color:black"> <i class="fa fa-twitter"

                                         style="font-size:24px"></i></i><span style="font-size:15px">

                                         {{ $contact->Twitter }} </span></a> <br> <br></font>



                             <font style="margin-left:10px"> <a href="{{ $contact->Instagram }}"

                                     style="text-decoration:none;color:black"> <i class="fa fa-instagram"

                                         aria-hidden="true" style="font-size:24px"></i><span style="font-size:15px">

                                         {{ $contact->Instagram }} </span></a> <br> <br></font>



                             <font style="margin-left:10px"> <a href="{{ $contact->Facebook }}"

                                     style="text-decoration:none;color:black"> <i class="fa fa-facebook-f"

                                         style="font-size:24px"></i><span style="font-size:15px">

                                         {{ $contact->Facebook }} </span></a> <br> <br></font>



                         </div>











                     </div>















                 </div>



             </div>



         </div>







         </div>



         {{-- Reviews  --}}







         <div class="part2" style="background-color:black;margin-top:5px">

             <h1 style="color:white;text-align:center"> Reaviews </h1>

         </div>

        

         @php

        

        @endphp



         <div class="reviews" style="margin-top:-30px;height:500px;">

            <div class="swiper mySwiper2" style="height:300px;">

                <div class="swiper-wrapper">

             @foreach ($review as $reviews)

                     <div class="swiper-slide" style="width:30%; height:40%">

                        <div class="row">

                             <div class="col">

                              <img src="{{$route.'/'.$reviews->Images}}" style="height:140px;width:200px">

                             </div>

                             <div class="col">

                            <h5>   {{$reviews->User_name}} </h5> 

                             </div>

                             <p  class="message"> {{$reviews->Message}} </p>

                             <input type="hidden" class="star_number" value="{{$reviews->Star}}">

                <p class="star">Star </p>



                         </div>

                     </div>

                 @endforeach   

                

         </div>

       

        </div>

      </div> 

         <div class="footer" style="margin-top:-190px">

          @include('folder/footer'); 

          </div>         



         <!-- Swiper JS -->



         <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>







         <!-- Initialize Swiper -->



         <script>



$(document).ready(function () {

    var starsHtml = '';

    

    $(".star_number").each(function () {

        var starValue = $(this).val();

      

        for (var i = 1; i <= starValue; i++) {

            starsHtml += '<img src="{{ $route }}/star.png" class="star_image" alt="Star" style="width:8%;float:left;height:25px;margin-top:10px"> ';

        }

        

        // Append the starsHtml to the corresponding element with class "star"

        $(this).siblings(".star").html(starsHtml);

        

        // Reset starsHtml for the next iteration

        starsHtml = '';

    });

});









             var swiper = new Swiper(".mySwiper", {



                 spaceBetween: 30,



                 effect: "fade",



                 autoplay: {



                     delay: 2500,



                     disableOnInteraction: false,



                 },



                 pagination: {



                     el: ".swiper-pagination",



                     clickable: true,



                 },



                 navigation: {



                     nextEl: ".swiper-button-next",



                     prevEl: ".swiper-button-prev",



                 },



             });











             var swiper = new Swiper(".mySwiper2", {



                 effect: "coverflow",



                 grabCursor: true,



                 centeredSlides: true,



                 slidesPerView: "auto",



                 coverflowEffect: {



                     rotate: 50,



                     stretch: 0,



                     depth: 100,



                     modifier: 1,



                     slideShadows: true,



                 },



                 pagination: {



                     el: ".swiper-pagination",



                 },



             });

         </script>



     </body>







     </html>

