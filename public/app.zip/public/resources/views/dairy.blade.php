
@include('folder/header'); 
@include('folder/link');
<?php
$dairy2=config('path.dairy'); 

?> 
<br> <br> 

<div class="ch" style="width:100%;height:70px;background-color:white;margin-top:8px"> 
<h1 style="text-align:center">    Dariy Product <hr style="width:20%;margin-left:40%">  </h1> 
</div> 

<br> <br> <br> 
<div class="per" style="width:50%;margin-left:28%">
<p> Lorem ipsum dolor sit amet consectetur, adipisicing elit. Enim magni, eius placeat nam excepturi corrupti 
pariatur autem delectus doloribus explicabo, exercitationem distinctio tempore officia voluptatem aut est quod accusamus. Dolorem?
</p> 
</div> 

<div class="part2" style="background-color:black;margin-top:5px"> 
 <h1 style="color:white;text-align:center"> Dariy Product  </h1> 
</div> 

<div class="part3" style="margin-top:5px;border:7px solid green"> 
<div class="container">

<div class="row"> 
   @foreach($dairy as $value)
<div class="col"> 
              <div class="card" style="width: 18rem;">
                <a href="/viewdairy/{{$value->productid}}/cus">
                <img src="{{$dairy2}}/{{$value->Image}}" class="card-img-top" alt="..." style="width:200px"></a>
                <div class="card-body">
                  <h5 class="card-title">{{$value->productname}}</h5>
                  <p class="card-text"><span>Original <strike> {{$value->originalprice }} &#8377 </strike></span> <span> Total  {{$value->Total}} &#8377</span> <span class="discount">Discount {{$value->Discount}}%</span></p>
                  <p> 
                  <a href="#" class="btn btn-primary">Buy</a>
                  <a href="/viewdairy/{{$value->productid}}/cus" class="btn btn-primary viewproduct">View</a>
                </div>
              </div>
        </div> 
@endforeach
</div>
</div>
</div> 
@include('folder/footer'); 

  