<script> 
  



</script>

@include('folder/header'); 
@include('folder/link');

<br> <br> 
<div class="ch" style="position:fixed;width:100%;height:70px;background-color:white;margin-top:8px"> 
<h1 style="text-align:center">    Contact us <hr style="width:20%;margin-left:40%">  </h1> 
</div> 
<br> <br> <br> 
<div class="per" style="width:50%;margin-left:28%">
<p> Lorem ipsum dolor sit amet consectetur, adipisicing elit. Enim magni, eius placeat nam excepturi corrupti 
pariatur autem delectus doloribus explicabo, exercitationem distinctio tempore officia voluptatem aut est quod accusamus. Dolorem?

</p> 
</div> 



<div class="part2" style="background-color:black;margin-top:5px"> 
 <h1 style="color:white;text-align:center"> Contact  </h1> 
</div> 
<div class="part3" style="margin-top:5px;border:7px solid green"> 
<div class="container-fluid">
<div class="row"> 
<div class="col-7 shadow"> 
<iframe src="{{$contact2->Ifram}}" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

<br> <br> 
<h5> Address </h5> 
<i class="fa fa-map-marker" style="font-size:25px;color:red"></i> <a href="{{$contact2->Location}}" style="color:black;text-decoration:none; "> {{$contact2->Address}} </a> 

<br> <br> 
<h5><b> Call Us</b> </h5> 
  <font style="margin-left:10px"> <a href="{{$contact2->Phone_number1}}" style="text-decoration:none;color:black"> <i class="fa fa-phone" aria-hidden="true" style="font-size:24px"></i><span style="font-size:15px">  +91 {{$contact2->Phone_number1}} </span></a> <br> </font> 
 <font style="margin-left:10px"> <a href="{{$contact2->Phone_number2}}" style="text-decoration:none;color:black"> <i class="fa fa-phone" aria-hidden="true" style="font-size:24px"></i><span style="font-size:15px">  +91 {{$contact2->Phone_number2}}  </span></a> <br> </font> 
<br> 

<h5> Email </h5>
<font style="margin-left:10px"> <i class="fa fa-envelope" style="font-size:25px"></i> <a href="{{$contact2->Address}}" style="color:black;text-decoration:none; "> {{$contact2->Email_id}} </a> </font>
<br>  <br> 
<h5> Follow us </h5> 
<font style="margin-left:10px"> 
<a href="{{$contact2->Twitter}}" style="text-decoration:none;color:black"> <i class="fa fa-twitter" style="font-size:24px"></i></a> &nbsp; 
<a href="{{$contact2->Instagram}}" style="text-decoration:none;color:black"><i class="fa fa-instagram" aria-hidden="true" style="font-size:24px"></i> </a> &nbsp; 
<a href="{{$contact2->Facebook}}" style="text-decoration:none;color:black"> <i class="fa fa-facebook-f" style="font-size:24px"> </i> </a>  &nbsp; </font>

<br> <br> 
</div> 


<div class="col-5" style="padding-top:40px"> 
<div class="form shadow rounded" style="position: sticky;
  top: 25%"> 
  @if($message = Session::get('success'))
<div class="alert alert-success alert-block">

<strong>  {{$message }}</strong>

 </div>
@endif   
  <form action="/contact" method="POST"> 
    @csrf
<h5> Send a message </h5> 
   
    
  <div class="mb-3">
    <label for="exampleInputEmail1" class="form-label" style="padding-left:20px;">Name</label>
    <input type="text" class="form-control" id="na" aria-describedby="emailHelp" name="name" value="{{old('name')}}" style="margin-left:20px;width:90%;">
     @if($errors->has('name'))
            <span class="text-danger error-style" style="margin-left:5%"> {{ $errors->first('name') }}</span>
            @endif 

   
  </div>
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label" style="padding-left:20px;">Email</label> 
    <input type="email" class="form-control" id="email" style="margin-left:20px;width:90%;" name="email" value="{{old('email')}}" >
    @if($errors->has('email'))
     <span class="text-danger error-style" style="margin-left:5%"> {{ $errors->first('email') }}</span>
            @endif 



  </div>
 
  
  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label" style="padding-left:20px;">Subject </label>
    <input type="text" class="form-control" id="subject" style="margin-left:20px;width:90%;" name="subject" value="{{old('subject')}}">

    @if($errors->has('subject'))
    <span class="text-danger error-style" style="margin-left:5%"> {{$errors->first('subject')}} </span>
    @endif
  </div>

  <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label" id="message2" style="padding-left:20px;">Message</label>
    <textarea class="form-control" id="message" style="margin-left:20px;width:90%;" name="message" value="{{old('message')}}"> </textarea>    
    @if($errors->has('message'))
    <span class="text-danger error-style" style="margin-left:5%"> {{$errors->first('message')}} </span>
    @endif
</div>

 
  <input type="submit" class="btn btn-success" style="margin-left:60px;" id="sb">
  <br><br> 
</form>
        </div> 
</div>

</div>


</div> 
</div> 
 
 </div> 
 
@include('folder/footer'); 
