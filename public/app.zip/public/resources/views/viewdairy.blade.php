

@include('folder/header');

@include('folder/link'); 
<?php

$dariy=config('path.dairy')

?>

<script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>

 

<br> <br> 

<div class="ch" style="position:fixed;width:100%;height:70px;background-color:white;margin-top:8px"> 

<h1 style="text-align:center"> Dairy Product  <hr style="width:20%;margin-left:40%">  </h1> 

</div>  <br> <br> <br> 





<div class="part2" style="background-color:black;margin-top:20px"> 

 <h1 style="color:white;text-align:center">{{$product->productname}}</h1> 

</div> 



 <div class="container"> 

 <div class="row"> 

  <div class="col-7"> 

 <img src="{{$dariy}}/{{$product->Image}}" style="width:50%;">

 </div> 





  <div class="col-5"> 

  <h5 style="text-align:center"> {{$product->productname}} </h5> 

  <h6> Price :             {{$product->Total}} ₹ </h6> 

  <h6>  Discount :       {{$product->Discount}}% </h6> 

  <h6> Information :        {{$product->description}} </h6> 

  <h6> Quantity  :        {{$product->Quanity}}  {{$product->Unit}}</h6> 

<br> <br> 

<button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="Buy" style="margin-left:1%">

    Buy 

</button>



<a href="/dairy/{{$product->productid}}/cart"><button type="button" class="btn btn-info" > Add to Cart </button>

</a>

  

 </div>

