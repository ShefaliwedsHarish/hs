<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ContactController; 
use App\Http\Controllers\usercontroller;
use App\Http\Controllers\adminController;
use App\Http\Controllers\userviewController;
use App\Http\Controllers\craousalcontroller;
use APP\Http\Controllers\managmentcontroller;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

//Route::get('/',[ContactController::class,'index']);


Route::get('/',[userviewController::class,'index']);
Route::get('/about',[userviewController::class,'about']);
Route::get('/contact',[userviewController::class,'contact']);
Route::get('/online',[userviewController::class,'online']);
Route::get('/epfoform',[userviewController::class,'epfo']);
Route::get('/itr_form',[userviewController::class,'itr_form']);
Route::get('/online2',[userviewController::class,'onlineform']);
Route::get('/photo',[userviewController::class,'photo']);
Route::get('/views',[userviewController::class,'view']);
//Route::get('/',[userviewController::class,'getdata'])
Route::get('/admin/{id}/view',[usercontroller::class,'viewsingle']);
Route:: get('/epfoview',[usercontroller::class,'epfo']);
Route:: get('/itrview',[usercontroller::class,'itr']);
Route::get('/admin2',[usercontroller::class,'admin']);
Route::get('/user',[usercontroller::class,'desh']);
Route:: post('/contact',[ContactController::class,'contact']);
Route::post('/epfo2',[ContactController::class,'epfo']);
Route::post('/itr2',[ContactController::class,'itr']);


// for admin

Route::get('/active',[adminController::class,'admin']);
Route::POST('/adduser',[adminController::class,'adminuser'])->name('admin_data');
Route::POST('/logindata',[adminController::class,'logindata'])->name('login');
Route::POST('/registerdata',[adminController::class,'registerdata'])->name('register');
Route::get('/setting',[adminController::class,'setting'])->name('setting');
Route::POST('setting/{id}/data',[adminController::class,'settingdata']); 
Route::POST('contact/{id}/data',[adminController::class,'contactedit']); 
Route::get('/userquery',[adminController::class,'userquery'])->name('userquery');
Route::get('/contact/{id}/update', [adminController::class,'viewmessage']);
Route::get('/contact/{id}/delete',[adminController::class,'deletemessage']);
Route::get('/readall',[adminController::class,'readall']);
Route::get('/deleteall',[adminController::class,'deleteall']);
//logout 
Route::get('/logout',[adminController::class,'logout'])->name('logout');

//User 
Route::get('/userdetails',[adminController::class,'useractive'])->name('users');
Route::get('use/{id}/change',[adminController::class,'checkuser']);

// profile
Route::get('/profile',function ()
{
    
   return view('folder/profile');
})->name('profile');

// update data 
Route::get('/editprofile',[adminController::class,'editprofile']); 
Route::POST('/hsgroup/{id}/editdata',[adminController::class,'editdata']); 
// craousel 
Route::get('/craousalshow',[craousalcontroller::class,'craousalshow'])->name('imagecraousal');
Route::POST('/savecraousal',[craousalcontroller::class,'imagesave']);
Route::get('/craousal/{id}/delete',[craousalcontroller::class,'deletecraousal']);

// Managment  
Route::POST('/managment',[craousalcontroller::class,'deletecraousal']);



