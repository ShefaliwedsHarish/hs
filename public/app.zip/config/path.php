<?php
return [
    'user' => '/public/adminuser/',
    'craousal'=>'/public/craousal',
    'review' => '/public/userprofile',
    'css'=>'public/admin',
    'about'=>'public/managment',
    'about2'=>'public/managmentimge',
    'loan'=>'public/image/',
    'dairy'=>'/public/dariy',
    'epfo'=>'/public/EPFO/',
    'itr'=>'/public/itr',
    
]; 

