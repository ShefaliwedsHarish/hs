<?php echo $__env->make('folder/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 
<?php echo $__env->make('folder/link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

<br> <br> 
<div class="ch" style="position:fixed;width:100%;height:70px;background-color:white;margin-top:8px"> 
<h1 style="text-align:center"> Photo <hr style="width:20%;margin-left:40%">  </h1> 
</div> 
<br> <br> <br> 
<div class="per" style="width:50%;margin-left:28%">
<p> Lorem ipsum dolor sit amet consectetur, adipisicing elit. Enim magni, eius placeat nam excepturi corrupti 
pariatur autem delectus doloribus explicabo, exercitationem distinctio tempore officia voluptatem aut est quod accusamus. Dolorem?</p> 
</div> 


<div class="part2" style="background-color:black;margin-top:5px"> 

 <h1 style="color:white;text-align:center"> Photos  </h1> 
</div> 


<div class="container"> 
<div class="row"> 

<div class="col" style="margin-top:20px;">

<div class="card" style="width: 18rem;">
<a href="/views" style="color:black;text-decoration:none"> 
  <img src="managment/mylife2.png" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Card</h5>
    <p class="card-text">Price :120₹  Discunt : 10 %</p>
     </a> 
    <a href="#" class="btn btn-primary">Buy</a>
  </div>
</div>
</div> 

<div class="col" style="margin-top:20px;">

<div class="card" style="width: 18rem;">
  <img src="managment/mylife2.png" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Card</h5>
    <p class="card-text">Price :120₹  Discunt : 10 %</p>
    <a href="#" class="btn btn-primary">Buy </a>
  </div>
</div>
</div> 


<div class="col" style="margin-top:20px;">

<div class="card" style="width: 18rem;">
  <img src="managment/mylife2.png" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Card </h5>
    <p class="card-text">Price :120₹  Discunt : 10 %</p>
    <a href="#" class="btn btn-primary">Buy </a>
  </div>
</div>
</div> 


<div class="col" style="margin-top:20px;">

<div class="card" style="width: 18rem;">
  <img src="managment/mylife2.png" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Card</h5>
    <p class="card-text">Price :120₹  Discunt : 10 %</p>
    <a href="#" class="btn btn-primary">Buy</a>
  </div>
</div>
</div> 



</div> 
</div 
<?php /**PATH D:\laraval\HSGroup\resources\views/photo.blade.php ENDPATH**/ ?>