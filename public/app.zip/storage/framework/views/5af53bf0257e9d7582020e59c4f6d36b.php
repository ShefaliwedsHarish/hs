
<script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<style>
  span.price_style {
    float: right;
}
input#exampleInputEmail1 {
    width: 26%;
    float: left;
}
</style>
<script> 

$(document).ready(function ()
{
   
   $(".plush").on("click",function ()
   {
    var qty=parseInt($(".qty").val());
    var num=1
     var d=qty+num; 
     $(".qty").val(d); 
     if(qty==5)
     {
       $(".qty").val(5); 
     }
     show(); 
   }); 


    $(".sub").on("click",function ()
   {
    var qty=parseInt($(".qty").val());
    var num=1
     var d=qty-num; 
     $(".qty").val(d); 
     if(qty==1)
     {
       $(".qty").val(1); 
     }
     show(); 
    
}); 

  function  show()
    {
        var qty=$(".qty").val();
        var price=$(".prid").val();  
    $.ajax({
          headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    },
       url:'/updatecart/'+qty+'/'+price,
       type:'POST',
       success:function (d)
       {
        location.reload();  
       }
  
  });

}


function sum()
{
      var price= parseInt($(".price").text()); 
      var discount=parseInt($(".discount").text()); 
      var coupons=parseInt($(".coupons").text()); 
      var delivery=parseInt($(".delivery").text()); 
      var total=price+delivery-discount-coupons; 
      $(".total").text(total); 
      var save=coupons+discount; 
      $(".save").text(save); 
}
sum();

});

</script>

<?php echo $__env->make('folder/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 
<?php echo $__env->make('folder/link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

<br> <br> 
<div class="ch" style="width:100%;height:70px;background-color:white;margin-top:8px"> 
<h1 style="text-align:center">View Cart <hr style="width:20%;margin-left:40%">  </h1> 
</div> 
<br> <br> <br> 
<div class="per" style="width:80%;margin-left:5%" >

<div class="container"> 
  <div class="row"> 
    <div class="col-9"> 
<div class="cart shadow">
 <h1> Shopping Cart </h1>
 <hr> 
 <div class="product shadow">

 <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="card mb-3" style="max-width: 540px;">
                <div class="row g-0">
                  <div class="col-md-4">
                    <img src="dariy/<?php echo e($cart->Image); ?>" class="img-fluid rounded-start" alt="...">
                  </div>
                  <div class="col-md-8">
                    <div class="card-body">
                      <input type="hidden" value="<?php echo e($cart->Product_id); ?>" class="prid">
                      <h5 class="card-title"><?php echo e($cart->Product_Name); ?></h5>
                      <p class="card-text"><span>&#x20B9 </span><?php echo e($cart->price); ?></p>
                      <p class="card-text">instock</p>


<div class="input-group">
  <button class="btn btn-outline-secondary plush" type="button"  >+</button>
  <input type="number" value="<?php echo e($cart->Quantity); ?>"  max="5" min="1"style="width:50px;text-align:center" class="qty" readonly=""> 
  <button class="btn btn-outline-secondary sub" type="button"  >-</button>

</div>

<br> 



                     <!--  <button> + </button>
                      <p class="card-text">Qty : <input type="number" value="<?php echo e($cart->Quantity); ?>"  max="5" min="1"style="width:50px;text-align:center" class="qty"> </p>
                      <button> - </button> -->
                      <a href="delete/<?php echo e($cart->Product_id); ?>/cart"><p class="card-text"><small class="text-body-secondary"><button type="button" class="btn btn-danger">Remove</button></small></p></a>
                    </div>
                  </div>
                </div>
              </div>
              <hr> <br> 
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 

 <div class="pagination">
        <?php echo e($carts->links()); ?>

</div>
<form> 

 <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Apply your coupns">
 <input type="submit" name="submit" class="btn btn-success" value="apply"> 
</form> 
<div class="button shadow" style="width:100%;height:50px"> 
<button type="button" class="btn btn-info" style="float:right">Place Order</button>
</div>
</div>
</div>
</div>


<div class="col-3"> 
 <div class="card shadow" style="width: 28rem;">
  <div class="card-body">
    <h5 class="card-title">PRICE DETAILS</h5>
    <hr> 
    
    <p class="card-text"><span class="style"> Price (<?php echo e($num); ?> item) </span>      <span class="price_style">     &#x20B9 <span class="price"><?php echo e($sum); ?> </span> </span>   </p>
    <p class="card-text"><span class="style"> Discount </span>       <span class="price_style">   &#x20B9 <span class="discount">35</span> </span>   </p>
    <p class="card-text"><span class="style"> Coupons for you </span>       <span class="price_style">   &#x20B9 <span class="coupons">30 </span> </span>   </p>
    <p class="card-text"><span class="delivery2"> Delivery Charges </span>       <span class="price_style">   &#x20B9 <span class="delivery"> 40 </span> </span>   </p>

   <hr> 
    <h3> <span class="style"> Total </span>       <span class="price_style">   &#x20B9 <span class="total"> </span></span>  </h3>
    <hr> 
    <p class="card-text"><span class="style"> You  Will save &#x20B9 <span class="save"></span>  On this Order  </span></p>

  </div>
</div>


</div>



</div>
</div>
</div>
 
<?php /**PATH D:\laraval\HSGroup\resources\views/cart/cart.blade.php ENDPATH**/ ?>