  <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1" />
  <!-- Link Swiper's CSS -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />

  <!-- Demo styles -->
  <style>
    html,
    body {
      position: relative;
      height: 100%;
    }

    body {
      background: #eee;
      font-family: Helvetica Neue, Helvetica, Arial, sans-serif;
      font-size: 14px;
      color: #000;
      margin: 0;
      padding: 0;
    }

   

    .swiper-slide {
      text-align: center;
      font-size: 18px;
      background: #fff;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .swiper-slide img {
      display: block;
      width: 100%;
      height: 100%;
      /*object-fit: cover;*/
    }

    .swiper {
      width: 100%;
      height: 400px;
      margin: 20px auto;
    }

    img.card-img-top {
    height: 235px;
}

  </style>
</head>

<?php echo $__env->make('folder/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 
<?php echo $__env->make('folder/link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 

<br><br> 
<div class="ch" style="position:fixed;width:100%;height:70px;background-color:white;margin-top:8px"> 
<h1 style="text-align:center">    About us <hr style="width:20%;margin-left:40%">  </h1> 
</div> 
<br> <br> <br> 
<div class="per" style="width:50%;margin-left:28%">
  
<p> Lorem ipsum dolor sit amet consectetur, adipisicing elit. Enim magni, eius placeat nam excepturi corrupti 
pariatur autem delectus doloribus explicabo, exercitationem distinctio tempore officia voluptatem aut est quod accusamus. Dolorem?</p> 
</div> 

<div class="part2" style="background-color:black;margin-top:5px"> 

 <h1 style="color:white;text-align:center"> Owner </h1> 
</div> 
<div class="onwer" style="border:7px solid green"> 


<div class="container"> 
<br> 
<div class="row shadow"> 
<div class="col" style="width:50%">
<h1> My Life  </h1> 
<p> Lorem ipsum dolor sit amet consectetur, adipisicing elit. Enim magni, eius placeat nam excepturi corrupti pariatur autem delectus doloribus explicabo, exercitationem distinctio tempore officia voluptatem aut est quod accusamus. Dolorem?</p> 
</div> 


<div class="col-4" style="width:50%">
<img src="managment/mylife.png"style="margin-left:40%;width:30%"> 

</div> 
</div> 

<br> <br> <br> 

<div class="row shadow"> 

<div class="col-4" style="width:50%">
<img src="managment/Harish.jpeg"style="width:30%"> 

</div> 


<div class="col" style="width:50%">
<h1> Harish   </h1> 
<p> Lorem ipsum dolor sit amet consectetur, adipisicing elit. Enim magni, eius placeat nam excepturi corrupti pariatur autem delectus doloribus explicabo, exercitationem distinctio tempore officia voluptatem aut est quod accusamus. Dolorem?</p> 
</div> 



</div> 

<br> 
</div> 
</div> 



<div class="part2" style="background-color:black;margin-top:5px"> 

 <h1 style="color:white;text-align:center"> Team Memebers  </h1> 
</div> 

<div class="details"style="border:7px solid green">

<div #swiperRef="" class="swiper mySwiper">
    <div class="swiper-wrapper">

      <?php $__currentLoopData = $managment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $managmet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="swiper-slide">
    <div class="card" style="width: 18rem;">
  <img src="managmentimge/<?php echo e($managmet->Images); ?>" class="card-img-top" alt="..." >
  <div class="card-body">
    <h5 class="card-title"><?php echo e($managmet->Name); ?> </h5>
    <p class="card-text"><?php echo e($managmet->Department); ?></p>
  </div>
                     
</div>       
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
</div>
      <br> <br> 
    <div class="swiper-button-next"></div>
    <div class="swiper-button-prev"></div>
    <br> <br> <br> <br> <br> 
    <div class="swiper-pagination"></div>
  </div>
  <br> <br> <br> <br> 
</div>








<br>
    <?php echo $__env->make('folder/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 

  <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>

  <!-- Initialize Swiper -->
  <script>
    var swiper = new Swiper(".mySwiper", {
      slidesPerView: 3,
      centeredSlides: true,
      spaceBetween: 30,
      pagination: {
        el: ".swiper-pagination",
        type: "fraction",
      },
      navigation: {
        nextEl: ".swiper-button-next",
        prevEl: ".swiper-button-prev",
      },
    });
  </script><?php /**PATH D:\laraval\HSGroup\resources\views/about.blade.php ENDPATH**/ ?>