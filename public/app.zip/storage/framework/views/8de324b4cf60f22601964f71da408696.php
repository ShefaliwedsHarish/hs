
<?php echo $__env->make('folder/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 
<?php echo $__env->make('folder/link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

<?php
$image="image/";
?> 


<!-- ========================Link======================================= -->



<!-- ========CSS=========================================================== -->
<style> 
@media (min-width: 1025px) {
.h-custom {
height: 100vh !important;
}
}

@media only screen and (max-width: 600px) {
 .card.rounded-3 {
    margin-top: -106%;
}
}


body {
background-color:  #8fc4b7;
margin: 0;
}
.row.d-flex.justify-content-center.align-items-center.h-100 {
    margin-top: -3%;
}
</style> 

<!-- ========bootstrap Html code ========== -->

 <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<body style="bg-color: #8fc4b7;">
<section class="h-100 h-custom" >
  <div class="container py-5 h-100">
    <div class="row d-flex justify-content-center align-items-center h-100">
      <div class="col-lg-8 col-xl-6">
        <div class="card rounded-3">
          <img src="<?php echo e($image); ?>image2.JPG"
            class="w-100" style="border-top-left-radius: .3rem; border-top-right-radius: .3rem; height:220px"
            alt="Sample photo">
          <div class="card-body p-4 p-md-5">
            <h3 class="mb-4 pb-2 pb-md-0 mb-md-5 px-md-2">Loan Request</h3>

            <form class="px-md-2" id="loan" enctype="multipart/form-data">
              <div class="form-outline mb-4">
                <input type="text" id="name" class="form-control" name="name" />
                <label class="form-label" for="form3Example1q">Name</label>
              </div>

              <div class="row">
                <div class="col-md-6 mb-4">
                  <div class="form-outline datepicker">
                    <input type="text" class="form-control" id="payment" name="payment" />
                    <label for="exampleDatepicker1" class="form-label">Payment</label>
                  </div>
                </div>

                <div class="col-md-6 mb-4">
                  <div class="form-outline datepicker">
                    <input type="text" class="form-control" id="returnpayment" name="paymentreturn"/>
                    <label for="exampleDatepicker1" class="form-label">Payment of return  </label>
                  </div>
                </div>
              </div>

              <div class="row">
                <div class="col-md-6 mb-4">
                  <div class="form-outline datepicker">
                    <input type="date" class="form-control" id="requestdate" name="requestdate" />
                    <label for="exampleDatepicker1" class="form-label">Request Date</label>
                  </div>
                </div>

                <div class="col-md-6 mb-4">
                  <div class="form-outline datepicker">
                    <input type="date" class="form-control" id="returndate" name="returndate"/>
                    <label for="exampleDatepicker1" class="form-label">Return date</label>
                  </div>
                </div>
              </div>




              <div class="row">
                <div class="col-md-6 mb-4">
                  <div class="form-outline datepicker">
                    <input type="text" class="form-control" id="pnnumber" name="pnnumber" />
                    <label for="exampleDatepicker1" class="form-label">Phone Number</label>
                  </div>
                </div>

                <div class="col-md-6 mb-4">
                  <select class="form-select" aria-label="Default select example" name="paymentmethod">
                    <option value="1" disabled>Payment Pay</option>
                    <option value="Googlepay">Google Pay </option>
                    <option value="Phonepay">Phone Pay</option>
                    <option value="Paytm">Paytm</option>
                  </select>
                </div>
              </div>


              <button type="submit" class="btn btn-success btn-lg mb-1" id="submit">Submit</button>

            </form>

          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<script> 
$(document).ready(function (){
$("#loan").submit(function (e){
e.preventDefault(); 
//var data=new FormData(this);
var data=$(this).serialize();
$.ajax({
      headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
         url:'/loanrequest',
         type:'POST',
         data:data,
         success:function (d){
          alert(d); 

         }
}) 
});



}); 

</script> <?php /**PATH /home/bplrvobq7a8r/public_html/resources/views/kst.blade.php ENDPATH**/ ?>