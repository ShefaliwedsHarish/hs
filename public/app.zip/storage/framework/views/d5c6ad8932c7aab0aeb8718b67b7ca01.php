
<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
<?php
    $route = "userprofile"; 
?>
<style>
img.star_image {
    height: 55px;
}
td {
    width: 10px;
}


</style> 
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


<script> 
  jQuery(document).ready(function ()
  {
    // imageroute
  jQuery(document).on("click",".view",function()
  {
  var id=jQuery(this).data("vid");
  jQuery.ajax({
    
  headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }, 
  url:"viewreview/"+id,
  type:"POST",
  success:function(d)
  { 
    console.log(d);
    var data=JSON.parse(d); 
    jQuery(".image").attr("src",'<?php echo e($route); ?>/'+data.Images);
    jQuery(".name").html(data.User_name); 
    jQuery(".message").html(data.Message); 
    var star=data.Star; 
    var starsHtml = '';
    for(a=1;a<=star;a++)
    {
        //  starsHtml += '★';
        starsHtml +='<img src="<?php echo e($route); ?>/star.png" class="star_image" alt="Star">'; 
    }
    jQuery(".star").html(starsHtml);
  }
  }); 
  });



  jQuery(document).on("click",".approve",function()
  {
  var id=jQuery(this).data("aid");
  jQuery.ajax({
    
  headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }, 
  url:"approvedreview/"+id,
  type:"POST",
  success:function(d)
  { 
     alert(d); 
     location.reload(); 
   }
  }); 
  });


 jQuery(document).on("click",".delete",function ()
 {
 var id=jQuery(this).data("did"); 
 jQuery.ajax({
  headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
 url:'reatingdelete/'+id,
 type:'POST',
 success:function(response)
 {
   alert(response); 
   location.reload(); 
 }
}); 
 
 });  

  
 jQuery(document).on("click",".edit",function ()
 {
 var id=jQuery(this).data("eid"); 
 jQuery.ajax({
  headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        },
 url:'reviewedit/'+id,
 type:'POST',
 success:function(response)
 {
   console.log(response)
   var data=JSON.parse(response) 
   var id=data.id; 
   var name=data.User_name; 
   var message=data.Message; 
   $("#messageid").val(id); 
   $("#name").val(name); 
   $("#message").text(message); 
 }
}); 
 
 });  
  
  
  }); 
  </script> 
<table class="table">     
    <thead>
      <tr>
        <th scope="col">Name</th>
        <th scope="col">User</th>
        <th scope="col">Message</th>
        <th scope="col">View</th>
        <th scope="col">Status</th>
        
        <th scope="col" colspan="4" style="text-align:center"> Action </th> 
      </tr>
    </thead>      
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tbody>
     <tr>
        <td><?php echo e($value->User_name); ?></td>
        <td><img src="<?php echo e($route.'/'.$value->Images); ?>" width="50px"> </td>
        <td><?php echo e($value->Message); ?></td>
        
        <td><button type="button" class="btn btn-primary view" data-bs-toggle="modal" data-bs-target="#exampleModal" data-vid="<?php echo e($value->id); ?>">
          view
        </button></td>
        <?php if($value->status==1): ?>
        <td><button type="button" class="btn btn-secondary approve" data-aid="<?php echo e($value->id); ?>">Approve</button></td>
        <?php else: ?>
        <td><button type="button" class="btn btn-info" data-aid="<?php echo e($value->id); ?>">Approved</button></td>
            
        <?php endif; ?>

        <td><button type="button" class="btn btn-secondary edit" data-bs-toggle="modal" data-bs-target="#edit" data-eid="<?php echo e($value->id); ?>">
         Edit
        </button>
          
          
          
          <button type="button" class="btn btn-danger delete" data-did="<?php echo e($value->id); ?>">Delete</button></td>
      </tr>
    </tbody>
 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  

  </table>
  <?php echo e($data->links()); ?>



<!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">View Rating </h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <div class="card-deck">
  <div class="card">
    <img class="card-img-top image" src="" alt="Card image cap" height="300px">
    <div class="card-body">
      <h5 class="card-title"><span class="name"></span></h5>
      <p class="card-text"> <span class="message"> </span> </p> 
      <h5 class="card-title"><span class="star"> </span>  </h5>    
  </div>
        
    
  </div>

</div> 
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
       </div>
    </div>
  </div>
</div>




<div class="modal fade" id="edit" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">Update Reviews </h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="updatereview" method="POST">
          <?php echo csrf_field(); ?>; 
          <div class="mb-3">
            <label for="exampleFormControlInput1" class="form-label">Name</label>
            <input type="hidden" id="messageid" name="messageid"> 
            <input type="text" class="form-control" id="name" readonly="" name="name">
          </div>
          <div class="mb-3">
            <label for="exampleFormControlTextarea1" class="form-label">Message</label>
            <textarea class="form-control" id="message" rows="3" name="message"></textarea>
          </div>
       
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" Value="UPDATE"> 
      </form>
      </div>
    </div>
  </div>
</div><?php /**PATH D:\laraval\HSGroup\resources\views/admin/rating.blade.php ENDPATH**/ ?>