<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>

<?php
$imgPath = config('path.user'); // Assuming 'path.user' is the correct configuration key

?>

<style>

img {

  border-radius: 10%;

  height:5%;

  width:40%;

}

</style>







<br> <br>



<table class="table">

  <thead>

    



    <tr>

      <!-- <th scope="col">Id</th> -->

      <th scope="col">Name</th>

      <th scope="col">Email</th>

      <th scope="col">User</th>

      <th scope="col">User_type</th>

      <th scope="col">Phone_number</th>

      <th scope="col">User_profile</th>

      <th scope="col">Status</th>

      <th scope="col" style="text-align:center">Action</th>

    </tr>





  </thead>

    <tbody>



  	<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

  	<tr>

      <!-- <th scope="row"><?php echo e($contact->id); ?></th> -->

      <td><?php echo e($contact->name); ?></td>

      <td><?php echo e($contact->email); ?></td>

      <td><?php echo e($contact->User); ?></td>

       <?php if($contact->User_type=="a"): ?>

      <td>Admin</td>

      <?php else: ?> 

      <td>Customer</td>

      <?php endif; ?>



      

      <td><?php echo e($contact->Phone_number); ?></td>

      <td style="width:10%"><img src="<?php echo e($imgPath); ?>/<?php echo e($contact->User_profile); ?>"> </td>
      <?php if($contact->status==1): ?>
      <td><button type="button" class="btn btn-success">Active</button></td>
      <?php else: ?> 
      <td><button type="button" class="btn btn-danger">Inactive</button></td>
      <?php endif; ?>


     <?php if($contact->use==1): ?>
      <td><a href="use/<?php echo e($contact->id); ?>/change"><button type="button" class="btn btn-light">Use</button></a> <a href="use/<?php echo e($contact->id); ?>/delete"><button type="button" class="btn btn-danger">Delete</button></a></td>
      <?php else: ?> 

      <td><a href="use/<?php echo e($contact->id); ?>/change"> <button type="button" class="btn btn-info">Not use </button></a> <a href="use/<?php echo e($contact->id); ?>/delete"><button type="button" class="btn btn-danger">Delete</button></a></td>

      <?php endif; ?>



     

         

   </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>















</table>

<?php /**PATH /home/bplrvobq7a8r/public_html/resources/views/admin/viewuser.blade.php ENDPATH**/ ?>