<?php echo $__env->make('folder/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 
<?php echo $__env->make('folder/link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;


<br> <br> 
<div class="ch" style="position:fixed;width:100%;height:70px;background-color:white;margin-top:8px"> 
<h1 style="text-align:center">   Online  Serive  <hr style="width:20%;margin-left:40%">  </h1> 
</div> 
<br> 
<div class="per" style="width:50%;margin-left:42%">
<br> <br> <br> 
<p>  <a href="/epfoform"> <button type="button" class="btn btn-secondary" id="epfo" value="EPFO">EPFO </button> </a> &nbsp; &nbsp; 
 <a href="/itr_form"> <button type="button" class="btn btn-info" id="itr" value="ITR">ITR</button> </a> &nbsp; &nbsp;  
 <a href="/online2"><button type="button" class="btn btn-warning" id="online" value="Online Form">Online Form </button> </p> </a>
</div> 

<div class="part2" style="background-color:black"> 
 <h1 style="color:white;text-align:center" id="act"> Online   </h1> 
</div> 

<div class="form" > 
<img src="managment/Capture.jpg"style="width:100%"> 
<img src="managment/logo.png" style=" width:120px;position:relative; margin-top:-107%;margin-left:45%">
<img src="managment/mylife.png" style=" width:120px;position:relative; margin-top:-107%;float:right"> 
<p> <img src="managment/h.png" style=" width:120px; height:110px; position:relative; margin-top:-107%;"></p> 
<div> 

<?php /**PATH D:\laraval\HSGroup\resources\views/online.blade.php ENDPATH**/ ?>