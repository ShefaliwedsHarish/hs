 
<div class="container" style="background-color:pink; border:7px solid green">


 <form>
      <div class="modal-body">


      
      <div  class="row"> 
    <div class="col-6"> 

<div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Name</label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required="">
   
  </div>

    </div> 
    <div class="col-6"> 

<div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Email </label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required="">
   
  </div>
             </div> 
    </div> 
      
  


        <div  class="row"> 
    <div class="col-6"> 

<div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Phone Number </label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required="">
   
  </div>

    </div> 
    <div class="col-6"> 

<div class="mb-3">
    <label for="exampleInputEmail1" class="form-label"> Addhar card    </label>
    <input type="file" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required="">
   
  </div>
             </div> 
    </div> 

      <div  class="row"> 
    <div class="col ">
<label for="exampleInputEmail1" class="form-label">Address   </label>
<div class="form-floating">
  <textarea class="form-control" placeholder="Leave a comment here" id="floatingTextarea" required="" ></textarea>
  <label for="floatingTextarea">Address </label>
</div>


             </div> 
    </div>






        <div  class="row"> 
    <div class="col-6"> 

<div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Pan Number   </label>
    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required="">
   
  </div>

    </div> 
    <div class="col-6"> 

<div class="mb-3">
    <label for="exampleInputEmail1" class="form-label">Password   </label>
    <input type="password" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" required="">
   
  </div>
             </div> 
    </div> 
             <input type="submit"  class="btn btn-success" name="sb" style="margin-left:45%"> 

</form> 
        










<?php /**PATH D:\laraval\HSGroup\resources\views/online/itr.blade.php ENDPATH**/ ?>