<?php
    function show($id)
    {
    switch($id)
    {
        case 1:
        echo "<h1> /craousal</h1>"; 
        break; 
    }
}

?><?php /**PATH D:\laraval\HSGroup\resources\views/image.blade.php ENDPATH**/ ?>