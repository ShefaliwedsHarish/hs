<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php 
$folder=config('path.itr');
$url=url('/'); 
?> 

<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>

 <script> 



$(document).ready(function ()

{

  $(document).on("click",".view",function ()

  {



    var id= $(this).data("id"); 

    

   $.ajax({

    headers: {

        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

    },

             url:"/admin/"+id+"/view",

             type:"POST",

             success:function (d)

             { 

              console.log(d);

              var data=JSON.parse(d); 

              jQuery("#name").text(data.Name);

              jQuery("#email").text(data.Email);

              jQuery("#phone").text(data.Phone_number);

              jQuery("#Address").text(data.Address);

              jQuery("#pancard").text(data.Pan_card);

              jQuery("#password").text(data.Password);

              jQuery("#img").attr("src",'<?php echo e($folder); ?>/'+data.Addharcard); 

                jQuery("#image_url").attr("href",'<?php echo e($url); ?>/<?php echo e($folder); ?>/'+data.Addharcard).attr("target", "_blank");

              

              // jQuery("#name").text(data.Name);



              

             }

            

    });  



  }); 

   



}); 





</script> 

        



            <!-- Table Start -->

            <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />



            <div class="container-fluid pt-4 px-4">

                <div class="row g-4" >

                    <div class="col-sm-12 col-xl-6" style="width:100%">

                        <div class="bg-light rounded h-100 p-4" style="overflow:scroll">

           <!-- epfo start  -->

                            <h6 class="mb-4">ITR</h6>

                         

                            <table class="table">



                                <thead>

                                    <tr>



                                        <th scope="col">Id</th>

                                        <th scope="col">Name</th>

                                        <th scope="col">Email</th>

                                        <th scope="col">Phone_Number </th>

                                        <th scope="col">Action</th>

                                       

                                    </tr>

                                </thead>

                                <tbody>

                                     <?php $__currentLoopData = $itr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

                                    <tr>

                                        <th scope="row" class="id"><?php echo e($ep->id); ?></th>

                                        <td><?php echo e($ep->Name); ?></td>

                                        <td><?php echo e($ep->Email); ?></td>

                                        <td><?php echo e($ep->Phone_number); ?></td>

                                        <td> <button type="button" class="btn btn-primary view" data-bs-toggle="modal" data-bs-target="#exampleModal" data-id="<?php echo e($ep->id); ?>"> 

  Views Data 

</button></td>                                      



                                    </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>

                            </table>

                            <?php echo e($itr->links()); ?>  

                        </div>

                    </div>

                    



<!-- Modal -->

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

  <div class="modal-dialog modal-lg">

    <div class="modal-content">

      <div class="modal-header">

        <h1 class="modal-title fs-5" id="exampleModalLabel">Itr </h1>

        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

      </div>

      <div class="modal-body">

          

        <div class="card mb-3" style="max-width: 540px;">

          <div class="row g-0">

            <div class="col-md-4">

            <a href="" id="image_url" > <img src="" class="img-fluid rounded-start" id="img"alt="..."></a> 

            </div>

            <div class="col-md-8">

              <div class="card-body">

                <h5 class="card-title" name="name"><span> Name :=></span> <span id="name"> Harish </span> </h5>

                <p class="card-text"><span>Email :=> </span> <span id="email">harishgautammay@gmail.com </span>   </p>

                <p class="card-text"><span>Phone_number :=>  </span> <span id="phone">8988479148 </span>  </p>

                <p class="card-text"><span>Address :=> </span> <span id="Address">VPO Pratha Teh Kasauli Distt. Solan Hp 173220 </span>   </p>

                <p class="card-text"><span> Pan Card :=><span id="pancard"> ACQ1234554  </p>

                <p class="card-text"><span> Password =>:</span> <span id="password"> adfasdfasfas</span> </p>

                

              </div>

            </div>

          </div>

        </div>

      </div>

      <div class="modal-footer">

        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

     

      </div>

    </div>

  </div>

</div>





<!-- epfo end  -->





 <?php echo $__env->make('admin/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 

            <!-- Footer Start -->

        

</body>



</html><?php /**PATH /home/bplrvobq7a8r/public_html/resources/views/admin/itrview.blade.php ENDPATH**/ ?>