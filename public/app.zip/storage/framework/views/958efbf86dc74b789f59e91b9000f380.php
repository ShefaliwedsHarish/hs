<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style type="text/css">

table th
{
 text-align:center;
 
}
table td
{
 text-align:center;
 
}

.action
{
 float: right;
}
</style>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>


<br> <br> <br> 
<div class="action">  <a href="/readall"> <button type="button" class="btn btn-success">Read All </button></a><a href="/deleteall"><button type="button" class="btn btn-danger">Delete All </button></a></div>

<table class="table">
  <thead>
    

    <tr>
      <!-- <th scope="col">Id</th> -->
      <th scope="col">Name</th>
      <th scope="col">Email</th>
      <th scope="col">Subject</th>
      <th scope="col">Message</th>
      <th scope="col">Action</th>
    </tr>


  </thead>
    <tbody>

  	<?php $__currentLoopData = $contact; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  	<tr>
      <!-- <th scope="row"><?php echo e($contact->id); ?></th> -->
      <td><?php echo e($contact->Name); ?></td>
      <td><?php echo e($contact->Email); ?></td>
      <td><?php echo e($contact->Subject); ?></td>
      <td><?php echo e($contact->Message); ?></td>

      <?php if($contact->Read==1): ?>
      
      <td style="display: flex"><pre><a href="contact/<?php echo e($contact->id); ?>/update"><button type="button" class="btn btn-success">Read</button></a>  <a href="contact/<?php echo e($contact->id); ?>/delete"><button type="button" class="btn btn-danger">Delete</button></a></pre></td>
    
      <?php else: ?> 
      
                <td><a href="contact/<?php echo e($contact->id); ?>/delete"> <button type="button" class="btn btn-danger">Delete</button></a></td>
      
    <?php endif; ?>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>







</table>
<?php /**PATH D:\laraval\HSGroup\resources\views/admin/userquery.blade.php ENDPATH**/ ?>