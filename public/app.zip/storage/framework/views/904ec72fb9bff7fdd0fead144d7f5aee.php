<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
<link
  rel="stylesheet"
  href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css"
/>
<style> 
a
{
text-decoration: none;
color: black;
}
    img.card-img-top {
    height: 300px;
}


a.btn.btn-danger {
    float: right;
    position: relative;
    margin-top: -137%;
    margin-right: -15px;
}

.col-4 {
    margin-top: 3%;
}



/*swiper js */



html,
    body {
      position: relative;
      height: 100%;
    }

    body {
      background: #eee;
      font-family: Helvetica Neue, Helvetica, Arial, sans-serif;
      font-size: 14px;
      color: #000;
      margin: 0;
      padding: 0;
    }

    .swiper-slide {
      text-align: center;
      font-size: 18px;
      background: #fff;
      display: flex;
      justify-content: center;
      align-items: center;
    }

    .swiper-slide img {
      display: block;
      width: 100%;
      height: 100%;
      object-fit: cover;
    }

    .swiper {
      width: 100%;
      height: 400px;
      margin: 20px auto;
    }

</style>

<body> 
	<br> 
	<div class="container" style="background-color:#F0F3F4"> 
		<br> 
       <div class="card" style="width: 90%;"> 	
        <div class="card-body">
        <div class="alert alert-success " role="alert" id="site" data-id="1"> 
          General Setting is update 
        </div>   
  <h5 style="float:left"> General Setting </h5> 
  	 <button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#sitesetting"style="margin-left:91%">
 <i class="bi bi-pencil-square"></i> Edit
</button>
  	<br> 
   
   <h5 class="card-title">Site Title </h5>
    <h6 class="card-subtitle mb-2 text-body-secondary"><?php echo e($id->sitetitle); ?></h6>
  </div>
  <div class="card-body">
    <h5 class="card-title">About  </h5>
   <p class="card-text"><?php echo e($id->description); ?></p>
  </div>
</div>

  <br> <br> <br> 







<div class="card" style="width: 90%;">     	
  <div class="card-body">

  <div class="alert alert-success " role="alert" id="success" data-id="1"> 

   Site is shutdown 

</div>   

  	<h5>Shut Down  </h5>

   <p style="flaot:left">  Site will be under maintance </p>

   	<div class="form-check form-switch" style="float:right;margin-top:-5%">

  <input class="form-check-input" type="checkbox" id="flexSwitchCheckChecked" checked>

  </div>

 </div>

 </div>



<!-- end site setting -->
<?php

$image=config('path.about2');

?> 


<br> <br> <br>      



       <div class="card" style="width: 90%;">    	

      <div class="card-body">

  	<h5 style="float:left"> Contact Details  </h5> 

  	 <button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#updatecontact"style="margin-left:91%">

 <i class="bi bi-pencil-square"></i> Edit

</button>

  	<br> 

<div class="row"> 

   <div class="col-6">	

   	       <br> <br> 

    		<h6 class="card-title">Address </h6>

    		<h6 class="card-subtitle mb-2 text-body-secondary"><?php echo e($contact->Address); ?> </h6>



  </div>

  <div class="col-6"> 

  	<br> <br> 

     <h6 class="card-title">Social Media   </h6>

    <a href=""> <i class="bi bi-facebook"></i>&nbsp;&nbsp;<?php echo e($contact->Facebook); ?> </a><br>

     <a href=""> <i class="bi bi-instagram"></i>&nbsp;&nbsp;<?php echo e($contact->Instagram); ?> </a><br> 

    <a href=""><i class="bi bi-twitter"></i> &nbsp;&nbsp;<?php echo e($contact->Twitter); ?></a>   

  </div>

 </div>

<div class="row"> 

   <div class="col-6">	

   	    		<h6 class="card-title">Location </h6>

    		<i class="bi bi-geo-alt-fill" style="float:left"></i><h6 class="card-subtitle mb-2 text-body-secondary" style="float:left"><?php echo e($contact->Location); ?></h6>

  </div>

  </div>

 <div class="row"> 

   <div class="col-6">	

   <br> <br> 

    		<h6 class="card-title">Phone-number </h6>

    	<i class="bi bi-telephone-fill"></i> <?php echo e($contact->Phone_number1); ?>	 <br> <br>

    	<i class="bi bi-telephone-fill"></i> <?php echo e($contact->Phone_number2); ?>


<br> <br> <br>

    		<h6 class="card-title">Email </h6><br>

    	<i class="bi bi-envelope" style="float:left"></i>	<h6 class="card-subtitle mb-2 text-body-secondary" style="float:left"><?php echo e($contact->Email_id); ?></h6><br><br>

    	

  </div>

    <div class="col-6">    	

    	   <h6 class="card-title">Iframe </h6>

     <iframe src="<?php echo e($contact->Ifram); ?>" width="100%" height="100%" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

     </div>

 </div>

<br> 



	</div></div>

	<br> <br> <br> 







<br> <br> <br> 





<div class="card" style="width: 90%;">  

    <div class="card-body">

      <div class="alert alert-success " role="alert" id="contact" data-id="1"> 

          Managment add

        </div>   

        <h5 style="float:left">Management  </h5> 

        <button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#managment"style="margin-left:91%">

        <i class="bi bi-plus-square"></i> Add </button>

         <br> 

         

         <div #swiperRef="" class="swiper mySwiper">

                        <div class="swiper-wrapper">

                          <?php $__currentLoopData = $managment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  

                              <div class="swiper-slide">

                                    

                                        <div class="card" style="width:18rem;margin-top:-50px">

                                            <img src="<?php echo e($image); ?>/<?php echo e($mang->Images); ?>" class="card-img-top" alt="..." style="height:300px" >

                                              <div class="card-body">

                                                    <h4 style="text-align:center"> <?php echo e($mang->Name); ?> </h4>

                                                     <a href="managment/<?php echo e($mang->id); ?>/delete" class="btn btn-danger">Delete</a>

                                              </div>

                                         </div>

                              </div>

                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                              

                        </div> 

                              <br> <br> <br> 

                                <div class="swiper-button-next"></div>

                                <div class="swiper-button-prev"></div>

                                <div class="swiper-pagination"></div>

         </div>

      </div>

  </div>





</div>

<!-- container -->

<script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>



<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>



<script> 



$(document).ready(function ()

{



$(".alert-success").hide(); 

var c=$(".alert-success").data('id');  



if(c=="1")

{

  const myTimeout = setTimeout(myGreeting, 5000);

}



else 

{

  

}



// const myTimeout = setTimeout(myGreeting, 5000);



function myGreeting() {

    $(".alert-success").hide();  

}



}); 





var swiper = new Swiper(".mySwiper", {

      slidesPerView: 3,

      centeredSlides: true,

      spaceBetween: 30,

      pagination: {

        el: ".swiper-pagination",

        type: "fraction",

      },

      navigation: {

        nextEl: ".swiper-button-next",

        prevEl: ".swiper-button-prev",

      },

    });





</script>



</body>







































































<!-- modal -->



<div class="modal fade" id="sitesetting" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

  <div class="modal-dialog">

    <div class="modal-content">

      <div class="modal-header">

        <h1 class="modal-title fs-5" id="General">General Setting </h1>

        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

      </div>

      <div class="modal-body">    

      <form action="setting/<?php echo e($id->id); ?>/data" method="POST"> 

       <?php echo csrf_field(); ?>

       <input type="hidden" value="<?php echo e($id->id); ?>">

    <div class="mb-3">

    <label for="exampleInputEmail1" class="form-label">Site Name </label>

    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="site" value="<?php echo e($id->sitetitle); ?>">

    </div>

  <div class="mb-3">

    <label for="exampleInputPassword1" class="form-label">	About </label>

    <textarea  class="form-control" id="exampleInputPassword1" name="about"

     ><?php echo e($id->description); ?> </textarea> 

  </div>

   </div>

      <div class="modal-footer">

        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

        <input type="submit" class="btn btn-primary" value="Submit" id="run">





</form>

      </div>

    </div>

  </div>

</div>





<!-- contact details -->



<div class="modal fade" id="updatecontact" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

  <div class="modal-dialog modal-xl">

    <div class="modal-content">

      <div class="modal-header">

        <h1 class="modal-title fs-5" id="exampleModalLabel">Contact Details</h1>

        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

      </div>

      <div class="modal-body">    

      <form action="contact/<?php echo e($id->id); ?>/data" method="POST"> 

       <?php echo csrf_field(); ?>

      

 <div class="row">

    <div class="col-6">

       <input type="hidden" value="<?php echo e($contact->id); ?>">

    <div class="mb-3">

    <label for="exampleInputEmail1" class="form-label">Address</label>

    <div class="input-group mb-3">

  <span class="input-group-text" id="inputGroup-sizing-default">Address</span>

  <input type="text" class="form-control" value="<?php echo e($contact->Address); ?>" name="address">

</div>

</div>

</div>





<div class="col-6">

      <div class="mb-3">

      <label for="exampleInputEmail1" class="form-label">Google Map </label>

      <div class="input-group mb-3">

      <span class="input-group-text" id="inputGroup-sizing-default"><i class="bi bi-geo-alt-fill"></i></span>

      <input type="text" class="form-control" value="<?php echo e($contact->Location); ?>" name="googlemap">

</div>

</div>

</div>

</div>





<div class="row">

    <div class="col-6">

        <div class="mb-3">

    <label for="exampleInputEmail1" class="form-label">Phone_number1</label>

    <div class="input-group mb-3">

  <span class="input-group-text" id="inputGroup-sizing-default"><i class="bi bi-telephone-fill"></i></span>

  <input type="text" class="form-control" value="<?php echo e($contact->Phone_number1); ?>" name="phone_number1">

</div>

</div>

</div>

<div class="col-6">

      <div class="mb-3">

      <label for="exampleInputEmail1" class="form-label">Phone_number2 </label>

      <div class="input-group mb-3">

      <span class="input-group-text" id="inputGroup-sizing-default"><i class="bi bi-telephone-fill"></i></i></span>

      <input type="text" class="form-control" value="<?php echo e($contact->Phone_number2); ?>" name="phone_number2">

</div>

</div>

</div>

</div>





<div class="row">

    <div class="col-6">

          <div class="mb-3">

    <label for="exampleInputEmail1" class="form-label">Email_id</label>

    <div class="input-group mb-3">

  <span class="input-group-text" id="inputGroup-sizing-default"><i class="bi bi-envelope" style="float:left"></i></span>

  <input type="text" class="form-control" value="<?php echo e($contact->Email_id); ?>" name="email">

</div>

</div>

</div>

<div class="col-6">

      <div class="mb-3">

      <label for="exampleInputEmail1" class="form-label">Facebook </label>

      <div class="input-group mb-3">

      <span class="input-group-text" id="inputGroup-sizing-default"><i class="bi bi-facebook"></i></span>

      <input type="text" class="form-control" value="<?php echo e($contact->Facebook); ?>" name="facebook">

</div>

</div>

</div>

</div>







<div class="row">

    <div class="col-6">

          <div class="mb-3">

    <label for="exampleInputEmail1" class="form-label">InstaGram </label>

    <div class="input-group mb-3">

  <span class="input-group-text" id="inputGroup-sizing-default"><i class="bi bi-instagram"></i></span>

  <input type="text" class="form-control" value="<?php echo e($contact->Instagram); ?>" name="instagram">

</div>

</div>

</div>

<div class="col-6">

      <div class="mb-3">

      <label for="exampleInputEmail1" class="form-label">Twitter </label>

      <div class="input-group mb-3">

      <span class="input-group-text" id="inputGroup-sizing-default"><i class="bi bi-twitter"></i></span>

      <input type="text" class="form-control" value="<?php echo e($contact->Twitter); ?>" name="twitter">

</div>

</div>

</div>

</div>



  <div class="mb-3">

    <label for="exampleInputPassword1" class="form-label"> Iframe  </label>

    <textarea  class="form-control" id="exampleInputPassword1" name="ifram"

    rows="5" ><?php echo e($contact->Ifram); ?> </textarea> 

  </div>

   </div>

      <div class="modal-footer">

        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

        <input type="submit" class="btn btn-primary" value="Submit" id="run">





</form>

      </div>

    </div>

  </div>

</div>





<!-- managment  -->





<div class="modal fade" id="managment" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

  <div class="modal-dialog">

    <div class="modal-content">

      <div class="modal-header">

        <h1 class="modal-title fs-5" id="General">Image Craousal  </h1>

        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

      </div>

      <div class="modal-body">    

      <form action="/managmentdata" method="POST" enctype="multipart/form-data"> 

      <?php echo csrf_field(); ?> 

      

      <div class="mb-3">

    <label for="exampleInputPassword1" class="form-label">Name</label>

    <input type="text" class="form-control" id="exampleInputPassword1" name="name">

  </div>





      <div class="mb-3">

    <label for="exampleInputPassword1" class="form-label">Image</label>

    <input type="file" class="form-control" id="exampleInputPassword1" name="image">

  </div>

      <div class="modal-footer">

        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

        <input type="submit" class="btn btn-primary" value="Submit" id="run">





</form>

      </div>

    </div>

  </div>

</div>



























<?php /**PATH /home/bplrvobq7a8r/public_html/resources/views/admin/setting.blade.php ENDPATH**/ ?>