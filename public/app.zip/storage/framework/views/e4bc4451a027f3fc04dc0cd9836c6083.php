

<?php echo $__env->make('folder/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 

<?php echo $__env->make('folder/link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;



<?php

$image=config('path.loan');

?> 





<!-- ========================Link======================================= -->



<!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script> -->



<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>



<!-- ========CSS=========================================================== -->

<style> 

@media (min-width: 1025px) {

.h-custom {

height: 100vh !important;

}

}



@media only screen and (max-width: 600px) {

 .card.rounded-3 {

    margin-top: -106%;

}

}





body {

background-color:  #8fc4b7;

margin: 0;

}

.row.d-flex.justify-content-center.align-items-center.h-100 {

    margin-top: -3%;

}



.alert{

        display: none;



}



.toast {

    margin-top: 45px !important;

}

.row.hide_token {

    display: none;

}

</style> 



<!-- ========bootstrap Html code ========== -->







 <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />

<body style="bg-color: #8fc4b7;">

<section class="h-100 h-custom" >

  <div class="container py-5 h-100">

    <div class="row d-flex justify-content-center align-items-center h-100">

      <div class="col-lg-8 col-xl-6">

        <div class="card rounded-3">

          <img src="<?php echo e($image); ?>image2.JPG"

            class="w-100" style="border-top-left-radius: .3rem; border-top-right-radius: .3rem; height:220px"

            alt="Sample photo">

          <div class="card-body p-4 p-md-5">

            <h3 class="mb-4 pb-2 pb-md-0 mb-md-5 px-md-2">Loan Request</h3>



            <form class="px-md-2" id="loan" enctype="multipart/form-data">

              <div class="form-outline mb-4">

                <input type="text" id="name" class="form-control" name="name" />

                <label class="form-label" for="form3Example1q">Name</label>

                <div class="alert alert-danger" role="alert" id="name_error">

                  A simple danger alert—check it out!

                 </div>

              </div>



              <div class="row">

                <div class="col-md-6 mb-4">

                  <div class="form-outline datepicker">

                    <input type="text" class="form-control" id="payment" name="payment" />

                    <label for="exampleDatepicker1" class="form-label">Payment</label>

                  </div>

                  <div class="alert alert-danger" role="alert" id="payment_error">

                  A simple danger alert—check it out!

                  </div>

                </div>



                <div class="col-md-6 mb-4">

                  <div class="form-outline datepicker">

                    <input type="text" class="form-control" id="returnpayment" name="paymentreturn" readonly=""/>

                    <label for="exampleDatepicker1" class="form-label">Payment of return  </label>

                  </div>



                  <div class="alert alert-danger" role="alert" id="paymentreturn_error">

                    A simple danger alert—check it out!

                  </div>



                </div>



              </div>



              <div class="row">

                <div class="col-md-6 mb-4">

                  <div class="form-outline datepicker">

                    <span class="form-control" id="requestdate" >0000/00/00</span>

                    <label for="exampleDatepicker1" id="datePicker" class="form-label">Request Date</label>

                    <input type="hidden" id="requestfield" name="requestdate">

                  </div>

                  <div class="alert alert-danger" id="requestdate_error"  role="alert">

  A simple danger alert—check it out!

</div>

                </div>



                <div class="col-md-6 mb-4">

                  <div class="form-outline datepicker">

                    <input type="date" class="form-control" id="returndate" name="returndate"/>

                    <label for="exampleDatepicker1" class="form-label">Return date</label>

                  </div>

                  <div class="alert alert-danger"  id="returndate_error" role="alert">

  A simple danger alert—check it out!

</div>

                </div>

              </div>









              <div class="row">

                <div class="col-md-6 mb-4">

                  <div class="form-outline datepicker">

                    <input type="text" class="form-control" id="pnnumber" name="pnnumber" />

                    <label for="exampleDatepicker1" class="form-label">Phone Number</label>

                  </div>

                  <div class="alert alert-danger" id="pnnumber_error" role="alert">

                   A simple danger alert—check it out!

                   </div>

                </div>



                <div class="col-md-6 mb-4">

                  <select class="form-select" aria-label="Default select example" name="paymentmethod">

                    <option value="1" disabled>Payment Pay</option>

                    <option value="Googlepay">Google Pay </option>

                    <option value="Phonepay">Phone Pay</option>

                    <option value="Paytm">Paytm</option>

                  </select>

                </div>

              </div>







             <div class="row hide_token" >

                <div class="col-md-6 mb-4">

                 <span class="text-danger" id="error_id"> </span>

                 

                </div>



                <div class="col-md-6 mb-4">

                  <input type="text" id="token" class="form-control" name="token_number" />

                <label class="form-label" for="form3Example1q">Token</label>

                </div>

              </div>

              







              <button type="submit" class="btn btn-success btn-lg mb-1" id="submit">Submit</button>



            </form>



          </div>

        </div>

      </div>

    </div>

  </div>

</section>





<script> 

$(document).ready(function (){

  cd = (new Date()).toISOString().split('T')[0];





$('#requestdate').text(cd);

$('#requestfield').val(cd);

$("#payment").on("keyup",function (){



var payment=$("#payment").val(); 

var total=parseInt(payment)+payment*2.5/100;

// alert(total); 

 $('#returnpayment').val(total); 





}); 





$("#loan").submit(function (e){

e.preventDefault(); 

//var data=new FormData(this);

var data=$(this).serialize();

$.ajax({

      headers: {

            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')

        },

         url:'/loanrequest',

         type:'POST',

         data:data,

         success:function (d){

      

            console.log(d); 

            var data=JSON.parse(d); 

            if(data.status==true){

             // $('#sitesetting').modal('hide');

              toastr.success(data.message, { timeOut: 9500 });

              //const myTimeout = setTimeout(reload, 5000);

             }

            else if(data.status==false){

             // $('#sitesetting').modal('hide');

              toastr.error(data.message, { timeOut: 9500 });

              $("#error_id").hide(); 

              //const myTimeout = setTimeout(reload, 5000);

             }

            else{

                   toastr.error(data.message, { timeOut: 9500 });

                   $("#error_id").text(data.message); 

                   $(".row.hide_token").show(); 

            }

      },

          error: function (xhr) {



                 console.log(xhr);

               if (xhr.status === 422) {

                    var errors = xhr.responseJSON.errors;

                     console.log(errors); 



                //     // Display validation errors in your form

                    $.each(errors, function (key, value) {

                        $('#'+key+'_error').show(); 

                        $('#'+key+'_error').text(value[0]);

                        setTimeout(myGreeting, 5000);



                    });

                 }

            }

}) 

});







function myGreeting() {

 

     //alert("heelo"); 

    $(".alert").hide(); 

 }







}); 



</script> <?php /**PATH /home/bplrvobq7a8r/public_html/resources/views/loan.blade.php ENDPATH**/ ?>