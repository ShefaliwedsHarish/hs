
<?php echo $__env->make('folder/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php echo $__env->make('folder/link', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 
<script src="https://code.jquery.com/jquery-3.7.0.js" integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>
 
<br> <br> 
<div class="ch" style="position:fixed;width:100%;height:70px;background-color:white;margin-top:8px"> 
<h1 style="text-align:center"> Dairy Product  <hr style="width:20%;margin-left:40%">  </h1> 
</div>  <br> <br> <br> 


<div class="part2" style="background-color:black;margin-top:20px"> 
 <h1 style="color:white;text-align:center"><?php echo e($product->productname); ?></h1> 
</div> 

 <div class="container"> 
 <div class="row"> 
  <div class="col-7"> 
 <img src="/dariy/<?php echo e($product->Image); ?>" style="width:50%;">
 </div> 


  <div class="col-5"> 
  <h5 style="text-align:center"> <?php echo e($product->productname); ?> </h5> 
  <h6> Price :             <?php echo e($product->Total); ?> ₹ </h6> 
  <h6>  Discount :       <?php echo e($product->Discount); ?>% </h6> 
  <h6> Information :        <?php echo e($product->description); ?> </h6> 
  <h6> Quantity  :        <?php echo e($product->Quanity); ?>  <?php echo e($product->Unit); ?></h6> 
<br> <br> 
<button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="Buy" style="margin-left:1%">
    Buy 
</button>

<a href="/dairy/<?php echo e($product->productid); ?>/cart"><button type="button" class="btn btn-info" > Add to Cart </button>
</a>
  
 </div>
<?php /**PATH D:\laraval\HSGroup\resources\views/viewdairy.blade.php ENDPATH**/ ?>