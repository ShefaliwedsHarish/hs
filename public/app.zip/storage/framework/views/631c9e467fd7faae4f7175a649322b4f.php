<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        


            <!-- Table Start -->
            <div class="container-fluid pt-4 px-4">
                <div class="row g-4" >
                    <div class="col-sm-12 col-xl-6" style="width:100%">
                        <div class="bg-light rounded h-100 p-4" style="overflow:scroll">
           <!-- epfo start  -->
                            <h6 class="mb-4">EPFO</h6>
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th scope="col">Id</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Phone_Number </th>
                                        <th scope="col">Passbook </th>
                                        <th scope="col">Address </th>
                                        <th scope="col">UNA </th>
                                        <th scope="col">Password </th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $epfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th scope="row"><?php echo e($ep->id); ?></th>
                                        <td><?php echo e($ep->Name); ?></td>
                                        <td><?php echo e($ep->Email); ?></td>
                                        <td><?php echo e($ep->Phone_number); ?></td>
                                        <td><?php echo e($ep->Images_passbook); ?></td>
                                        <td><?php echo e($ep->Address); ?></td>
                                        <td><?php echo e($ep->UNA); ?></td>
                                         <td><?php echo e($ep->Password); ?></td>

                                    </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                </tbody>
                            </table>
                        </div>
                    </div>


<!-- epfo end  -->


 <?php echo $__env->make('admin/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>; 
            <!-- Footer Start -->
        
</body>

</html><?php /**PATH D:\laraval\HSGroup\resources\views/admin/table.blade.php ENDPATH**/ ?>