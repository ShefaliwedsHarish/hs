<?php echo $__env->make('admin/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>

<style>
	img.card-img-top {
    height: 300px;
}

a.btn.btn-danger {
    float: right;
    position: relative;
    margin-top: -133%;
    margin-right: -15px;
}
.col-4 {
    margin-top: 3%;
}

</style>



<script> 

$(document).ready(function ()
{

$(".alert-success").hide(); 
var c=$(".alert-success").data('id');  

if(c=="1")
{
  const myTimeout = setTimeout(myGreeting, 5000);
}

else 
{
  
}

// const myTimeout = setTimeout(myGreeting, 5000);

function myGreeting() {
    $(".alert-success").hide();  
}

}); 


</script>


<body> 
	<br> 
	<div class="container" style="background-color:#F0F3F4"> 
		<br> 
    
       <div class="card" style="width: 90%;"> 	
        <div class="card-body">
     	
        <div class="alert alert-success " role="alert" id="site" data-id="1"> 
          Images Craousal  is update 
        </div>   
       

  <h5 style="float:left"> Images Craousal  </h5> 
  	 <button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#sitesetting"style="margin-left:70%">
 <i class="bi bi-pencil-square"></i> Add
</button>
  	<br> 
<div class="row"> 
   
   <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

   <div class="col-4"> 
    <div class="card" style="width:95%;">
  <img src="craousal/<?php echo e($cra->images); ?>" class="card-img-top" alt="..." >
  <div class="card-body">
    
    <a href="/craousal/<?php echo e($cra->id); ?>/delete" class="btn btn-danger">Delete</a>
  </div>
</div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>



</div>
   <br> <br> <br> 
</div>




<div class="modal fade" id="sitesetting" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="General">Image Craousal  </h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">    
      <form action="/savecraousal" method="POST" enctype="multipart/form-data"> 
      <?php echo csrf_field(); ?> 
      <div class="mb-3">
    <label for="exampleInputPassword1" class="form-label">Image</label>
    <input type="file" class="form-control" id="exampleInputPassword1" name="craousal">
  </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <input type="submit" class="btn btn-primary" value="Submit" id="run">


</form>
      </div>
    </div>
  </div>
</div>

<?php /**PATH D:\laraval\HSGroup\resources\views/admin/craousal.blade.php ENDPATH**/ ?>