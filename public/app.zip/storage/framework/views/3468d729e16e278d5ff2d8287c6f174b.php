<?php
$imgPath = config('path.user'); // Assuming 'path.user' is the correct configuration key

?>

  <style> 

{

  font-color:white; 

}

.sitereview {

    margin-right: 2%;

}



* {

  -webkit-box-sizing:border-box;

  -moz-box-sizing:border-box;

  box-sizing:border-box;

}



*:before, *:after {

-webkit-box-sizing: border-box;

-moz-box-sizing: border-box;

box-sizing: border-box;

}



.clearfix {

  clear:both;

}



.text-center {text-align:center;}



a {

  color: tomato;

  text-decoration: none;

}



a:hover {

  color: #2196f3;

}



pre {

display: block;

padding: 9.5px;

margin: 0 0 10px;

font-size: 13px;

line-height: 1.42857143;

color: #333;

word-break: break-all;

word-wrap: break-word;

background-color: #F5F5F5;

border: 1px solid #CCC;

border-radius: 4px;

}



.header {

  padding:20px 0;

  position:relative;

  margin-bottom:10px;

  

}



.header:after {

  content:"";

  display:block;

  height:1px;

  background:#eee;

  position:absolute; 

  left:30%; right:30%;

}



.header h2 {

  font-size:3em;

  font-weight:300;

  margin-bottom:0.2em;

}



.header p {

  font-size:14px;

}







#a-footer {

  margin: 20px 0;

}



.new-react-version {

  padding: 20px 20px;

  border: 1px solid #eee;

  border-radius: 20px;

  box-shadow: 0 2px 12px 0 rgba(0,0,0,0.1);

  

  text-align: center;

  font-size: 14px;

  line-height: 1.7;

}



.new-react-version .react-svg-logo {

  text-align: center;

  max-width: 60px;

  margin: 20px auto;

  margin-top: 0;

}











.success-box {

  margin:50px 0;

  padding:10px 10px;

  border:1px solid #eee;

  background:#f9f9f9;

}



.success-box img {

  margin-right:10px;

  display:inline-block;

  vertical-align:top;

}



.success-box > div {

  vertical-align:top;

  display:inline-block;

  color:#888;

}







/* Rating Star Widgets Style */

.rating-stars ul {

  list-style-type:none;

  padding:0;

  

  -moz-user-select:none;

  -webkit-user-select:none;

}

.rating-stars ul > li.star {

  display:inline-block;

  

}



/* Idle State of the stars */

.rating-stars ul > li.star > i.fa {

  font-size:2.5em; /* Change the size of the stars */

  color:#ccc; /* Color on idle state */

}



/* Hover state of the stars */

.rating-stars ul > li.star.hover > i.fa {

  color:#FFCC36;

}



/* Selected state of the stars */

.rating-stars ul > li.star.selected > i.fa {

  color:#FF912C;

}



  </style> 



<script src="https://code.jquery.com/jquery-3.7.1.js" integrity="sha256-eKhayi8LEQwp4NKxN+CfCh+3qOVUtJn3QNZ0TciWLP4=" crossorigin="anonymous"></script>      

<script>



  $(document).ready(function(){

 $(document).on("click",".star",function ()

{

var id=$(this).data("value");

$("#star").val(id);

});





  $('#stars li').on('mouseover', function(){

    var onStar = parseInt($(this).data('value'), 10); 

    $(this).parent().children('li.star').each(function(e){

      if (e < onStar) {

        $(this).addClass('hover');

      }

      else {

        $(this).removeClass('hover');

      }

    });

    

  }).on('mouseout', function(){

    $(this).parent().children('li.star').each(function(e){

      $(this).removeClass('hover');

    });

  });

  

  

  /* 2. Action to perform on click */

  $('#stars li').on('click', function(){

    var onStar = parseInt($(this).data('value'), 10); // The star currently selected

    var stars = $(this).parent().children('li.star');

    

    for (i = 0; i < stars.length; i++) {

      $(stars[i]).removeClass('selected');

    }

    

    for (i = 0; i < onStar; i++) {

      $(stars[i]).addClass('selected');

    }

    



    

  });

  

  

});





// function responseMessage(msg) {

//   $('.success-box').fadeIn(200);  

//   $('.success-box div.text-message').html("<span>" + msg + "</span>");

// }



</script>



<nav class="navbar navbar-expand-lg  navbar-dark bg-dark  px-lg-3 pt-lg- shadow-sm fixed-top"> 

  <div class="container-fluid">

    <a class="navbar-brand" href="#">HSGroup</a>

    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">

      <span class="navbar-toggler-icon"></span>

    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">

      <ul class="navbar-nav me-auto mb-2 mb-lg-0">

        <li class="nav-item">

          <a class="nav-link active" aria-current="page" href="/" >Home</a>

        </li>





        

  <li class="nav-item">

          <a class="nav-link active" aria-current="page" href="/about" >About Us </a>

        </li>





        

        <li class="nav-item dropdown">

          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">

            Service  

          </a>

          <ul class="dropdown-menu">

            <li><a class="dropdown-item" href="/online">Online</a></li>

            <li><a class="dropdown-item" href="/ch">Material</a></li>

            <li><a class="dropdown-item" href="<?php echo e(route('loan')); ?>">Loan</a></li>

            <li><a class="dropdown-item" href="<?php echo e(route('kst')); ?>">KST Requirement</a></li>

            <li><a class="dropdown-item" href="/dairy">Dairy</a></li>

            <li><a class="dropdown-item" href="/photo">Printing</a></li>

            

          </ul>

        </li>

      

      

  <li class="nav-item">

          <a class="nav-link active" aria-current="page" href="/contact" >Contact us </a>

        </li>









        <li class="nav-item">

          <a class="nav-link active" aria-current="page" href="/photo" >Photo </a>

        </li>



 

      </ul>

    

 <?php if(isset(Auth::user()->User_type) && Auth::user()->User_type=="c"): ?>

 {



     <button type="button" class="btn btn-light sitereview" data-bs-toggle="modal" data-bs-target="#exampleModal">

  Reviews 

</button>

    <a href="/viewcart">  <button type="button" class="btn btn-light"> 

              <i class="fa fa-shopping-cart" style="font-size:24px"></i><sub> <font style="color:red; font-size:19px"><?php echo e(Session::get('num')); ?> </font> </sub>

           </button> </a>

                       



          <div class="nav-item dropdown">

                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">

                            <img class="rounded-circle me-lg-2" src="<?php echo e($imgPath . Auth::user()->User_profile); ?>" alt="" style="width: 40px; height: 40px;">

                            <span class="d-none d-lg-inline-flex" style="color:white"><?php echo e(Auth::user()->name); ?></span>

                        </a>

                        <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">

                            <a href="<?php echo e(route('profile')); ?>" class="dropdown-item">My Profile</a>

                            <a href="" class="dropdown-item"> My cart </a>

                            <a href="#" class="dropdown-item">Settings</a>

                            <a href="#" class="dropdown-item">Order</a>

                            <a href="<?php echo e(route('logout')); ?>" class="dropdown-item">Log Out</a>

                        </div>

                    </div>



}

<?php elseif(isset(Auth::user()->User_type) && Auth::user()->User_type=="a"): ?>

 {



     <button type="button" class="btn btn-light sitereview" data-bs-toggle="modal" data-bs-target="#exampleModal">

  Reviews 

</button>

    <a href="/viewcart">  <button type="button" class="btn btn-light"> 

              <i class="fa fa-shopping-cart" style="font-size:24px"></i><sub> <font style="color:red; font-size:19px"><?php echo e(Session::get('num')); ?> </font> </sub>

           </button> </a>

                       



          <div class="nav-item dropdown">

                        <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">

                            <img class="rounded-circle me-lg-2" src="<?php echo e($imgPath . Auth::user()->User_profile); ?>" alt="" style="width: 40px; height: 40px;">

                            <span class="d-none d-lg-inline-flex" style="color:white"><?php echo e(Auth::user()->name); ?></span>

                        </a>

                        <div class="dropdown-menu dropdown-menu-end bg-light border-0 rounded-0 rounded-bottom m-0">

                           <a href="/deshbord" class="dropdown-item">Deshbord</a>
                            <a href="" class="dropdown-item"> My cart </a>
                            <a href="#" class="dropdown-item">Settings</a>
                            <a href="#" class="dropdown-item">Order</a>



                            <a href="<?php echo e(route('logout')); ?>" class="dropdown-item">Log Out</a>

                        </div>

                    </div>



}













<?php else: ?>

{



      <button type="button" class="btn btn-light sitereview" data-bs-toggle="modal" data-bs-target="#exampleModal">

  Reviews 

</button>

<button type="button" class="btn btn-light" data-bs-toggle="modal" data-bs-target="#login"> 

    Login 

</button>



 

<button type="button" class="btn btn-light" data-bs-toggle="modal" data-bs-target="#Regester" style="margin-left:1%">

    Regester  

</button>



}

<?php endif; ?>

    </div>

  </div>

</nav>







<br> 

<!-- Modal -->

<div class="modal fade" id="login" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

  <div class="modal-dialog">

    <div class="modal-content">

      <div class="modal-header">

       <i class="fa fa-user" style="font-size:48px;"></i>  <h1 class="modal-title fs-5" id="exampleModalLabel" style="margin-left:40%">Login </h1>

        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

      </div>

      <form action="<?php echo e(route('login')); ?>" method="POST" enctype="multipart/form-data">

        <?php echo csrf_field(); ?>

      <div class="modal-body">

      <div class="mb-3">

    <label for="exampleInputEmail1" class="form-label">User Id </label>

    <input type="Text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="user">

   

  </div>

  <div class="mb-3">

    <label for="exampleInputPassword1" class="form-label">Password</label>

    <input type="password" class="form-control" id="exampleInputPassword1" name="password">

  </div>

 

      </div>

      <div class="modal-footer">



        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

        <button type="submit" class="btn btn-primary">Submit</button>

        </form> 

      </div>

    </div>

  </div>

</div>















<form action="<?php echo e(route('register')); ?>" method="POST" enctype='multipart/form-data'>

  <?php echo csrf_field(); ?>

<div class="modal fade" id="Regester" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

  <div class="modal-dialog modal-lg">

    <div class="modal-content">

      <div class="modal-header">

     <i class="fa fa-user-plus" style="font-size:48px;"></i>   <h1 class="modal-title fs-5" id="exampleModalLabel" style="margin-left:40%">Regester </h1>

        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

      </div>

      <form>

      <div class="modal-body">





      

      <div  class="row"> 

    <div class="col-6"> 



<div class="mb-3">

    <label for="exampleInputEmail1" class="form-label">Name</label>

    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="name">

   

  </div>



    </div> 

    <div class="col-6"> 



<div class="mb-3">

    <label for="exampleInputEmail1" class="form-label">Email </label>

    <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="email">

   

  </div>

             </div> 

    </div> 

      

  





        <div  class="row"> 

    <div class="col-6"> 



<div class="mb-3">

    <label for="exampleInputEmail1" class="form-label">Phone Number </label>

    <input type="number" class="form-control" aria-describedby="emailHelp" name="phone_number">

</div>



    </div> 

    <div class="col-6"> 



<div class="mb-3">

    <label for="exampleInputEmail1" class="form-label">Image   </label>

    <input type="file" class="form-control"  aria-describedby="emailHelp" name="user_profile">

   

  </div>

             </div> 

    </div> 



  

        <div  class="row"> 

    <div class="col-6"> 



<div class="mb-3">

    <label for="exampleInputEmail1" class="form-label">User Id </label>

    <input type="text " class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="user">

   

  </div>



    </div> 

    <div class="col-6"> 



<div class="mb-3">

    <label for="exampleInputEmail1" class="form-label">Password  </label>

    <input type="password" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="password">

   

  </div>

             </div> 

    </div> 

  

    </div>

      <div class="modal-footer">



        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

        <button type="submit" class="btn btn-primary">Submit</button>

        </form> 

      </div>

    </div>

  </div>

</div>

 







<!-- reating  -->

<!-- Modal -->

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">

  <div class="modal-dialog">

    <div class="modal-content">

      <div class="modal-header">

        <h1 class="modal-title fs-5" id="exampleModalLabel">Reviews</h1>

        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

      </div>

      <div class="modal-body">

          

<form action="/savereview" method="POST" enctype="multipart/form-data">

   <?php echo csrf_field(); ?>

    <div class="mb-3">

    <label for="exampleInputEmail1" class="form-label">Name</label>

    <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="name">

    </div>

    <div class="mb-3">

    <label for="exampleInputPassword1" class="form-label">Image</label>

    <input type="file" class="form-control" id="exampleInputPassword1" name="file">

    </div>



    <div class="mb-3">

    <label for="exampleInputPassword1" class="form-label">Message</label>

    <textarea class="form-control" name="message"> </textarea>

    </div>



    <div class="mb-3">

      <input type="hidden" class="form-control" id="exampleInputPassword1">

    </div>



    <div class="mb-3">

    <label for="exampleInputPassword1" class="form-label">Reating</label><br> 

   <div class='rating-stars text-center'>

    <ul id='stars'>

      <li class='star' title='Poor' data-value='1' >

        <i class='fa fa-star fa-fw'></i>

      </li>

      <li class='star' title='Fair' data-value='2'>

        <i class='fa fa-star fa-fw'></i>

      </li>

      <li class='star' title='Good' data-value='3'>

        <i class='fa fa-star fa-fw'></i>

      </li>

      <li class='star' title='Excellent' data-value='4'>

        <i class='fa fa-star fa-fw'></i>

      </li>

      <li class='star' title='WOW!!!' data-value='5'>

        <i class='fa fa-star fa-fw'></i>

      </li>

    </ul>

</div>





    <input type="hidden" name="start" id="star">



    </div>

     

      </div>

      <div class="modal-footer">

        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>

        <input type="submit" class="btn btn-primary">

          </form>

      </div>

    </div>

  </div>

</div><?php /**PATH /home/bplrvobq7a8r/public_html/resources/views/folder/header.blade.php ENDPATH**/ ?>